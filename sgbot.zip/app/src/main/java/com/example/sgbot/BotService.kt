package com.example.sgbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import org.opencv.android.OpenCVLoader
import org.opencv.core.Mat
import java.util.concurrent.Executor

class BotService : AccessibilityService() {

    companion object {
        private const val TAG = "SGBot"
        const val PREFS = "sgbot"
        const val DEFAULT_GAME_PKG = "com.pixio.google.mtd"

        /** true لما البوت مفعّل واللعبة هي الشاشة الحالية. */
        @Volatile var gameActive = false
        @Volatile var gamePkg = DEFAULT_GAME_PKG
        private val logLines = ArrayDeque<String>()

        @Synchronized
        fun log(msg: String) {
            Log.i(TAG, msg)
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logLines.addFirst("$t  $msg")
            while (logLines.size > 60) logLines.removeLast()
        }

        @Synchronized
        fun recentLog(): String = logLines.joinToString("\n")
    }

    private enum class Mode { IDLE, AD }

    private val main = Handler(Looper.getMainLooper())
    private val workerThread = HandlerThread("sgbot-worker").also { it.start() }
    private val worker = Handler(workerThread.looper)
    private val executor = Executor { worker.post(it) }

    private lateinit var det: Detector
    private var ready = false
    private var busy = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var eventPkg: String? = null      // آخر حزمة وصلت من أحداث النوافذ
    private var overlay: TextView? = null     // الأيقونة العايمة (بتظهر جوه اللعبة بس)
    private var overlayLp: WindowManager.LayoutParams? = null

    // حالة الـ state machine
    private var mode = Mode.IDLE
    private var adStart = 0L
    private var lastTap = 0L
    private var cooldownUntil = 0L        // بعد ما نخلص تاجر/مونيتور نتجاهل الشخصية وهي ماشية
    private var lastSpriteTap = 0L
    private var lastTrophyTap = 0L
    private var popupKey: String? = null
    private var popupSince = 0L
    private var offerCooldownUntil = 0L
    private var busySince = 0L
    private var lastCaptureAt = 0L
    private var adSawAway = false          // الإعلان ظهر فعلًا (شاشة اللعب اختفت)
    private var achPhaseSwipes = 0
    private var lastFgLogged: String? = null

    // تدفق الفوز/الخسارة: بنأكد على شاشة اختيار الوحوش بس لو إحنا اللي بدأنا التدفق
    private var winFlowUntil = 0L
    private var placeFlowUntil = 0L
    private var mapScrolls = 0

    // قائمة المهام
    private val ocr by lazy { Ocr() }
    private var qTaskId = -1L             // المهمة اللي بنشتغل عليها (عشان نصفّر العدادات لما تتغير)
    private var qScrolls = 0
    private var qDirDown = true
    private var qFlips = 0
    private var qTapTries = 0
    private var qPrevSig: Mat? = null
    private var ocrTries = 0
    private var lvStreakVal = -1          // آخر قراءة ليفل، وكام مرة اتكررت ورا بعض (للتأكد منها)
    private var lvStreak = 0
    private var lastConfirmTap = 0L
    private var lastOcrAt = 0L
    private var ocrStartAt = 0L
    private var mapOpenPending = 0L       // وقت آخر ضغطة على زرار فتح الخريطة (لو لسه مستنيين تظهر)

    // حالة نافذة الإنجازات
    private var achPhase = 0              // 0: اسحب لأعلى القائمة، 1: انزل لآخرها، 2: اقفل
    private var achSwipes = 0
    private var prevSig: Mat? = null

    private var sx = 1f
    private var sy = 1f

    private val loop = object : Runnable {
        override fun run() {
            try {
                val pkgNow = currentPackage()
                if (pkgNow != lastFgLogged) {
                    lastFgLogged = pkgNow
                    log("الشاشة الحالية: ${pkgNow ?: "؟"}")
                }
                val inGame = pkgNow == gamePkg
                if (inGame) showOverlay() else hideOverlay()

                if (inGame && enabled()) {
                    if (!gameActive) {
                        gameActive = true
                        log("اللعبة اتفتحت، البوت بدأ")
                    }
                    acquireWake()
                    capture()
                } else {
                    if (gameActive) {
                        gameActive = false
                        resetState()
                        log(if (inGame) "البوت اتوقف" else "اللعبة مش على الشاشة، البوت مستني")
                    }
                    releaseWake()
                }
            } catch (e: Throwable) {
                log("خطأ: ${e.message}")
            }
            main.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!OpenCVLoader.initLocal()) {
            log("OpenCV مش راضي يشتغل")
            return
        }
        det = Detector(this)
        gamePkg = resolveGamePackage()
        ready = true
        startKeepAlive()
        log("الخدمة اتوصلت. اللعبة: $gamePkg")
        main.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        // نتجاهل نافذة النظام ولوحة المفاتيح: الشاشة الحقيقية هي اللي تحتهم
        if (p == "com.android.systemui" || p.contains("inputmethod") || p == packageName) return
        eventPkg = p
        // رد فعل فوري لما اللعبة تفتح، من غير ما نستنى الدورة الجاية
        if (ready) {
            main.removeCallbacks(loop)
            main.post(loop)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        hideOverlay()
        releaseWake()
        gameActive = false
        workerThread.quitSafely()
        super.onDestroy()
    }

    // ---------- اكتشاف اللعبة ----------
    private fun resolveGamePackage(): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        if (apps.any { it.activityInfo.packageName == DEFAULT_GAME_PKG }) return DEFAULT_GAME_PKG
        // لو الحزمة الافتراضية مش موجودة: دوّر بالاسم (ونستثني تطبيقنا هو)
        val byLabel = apps.firstOrNull {
            it.activityInfo.packageName != packageName &&
                it.loadLabel(pm).toString().contains("summoner", ignoreCase = true)
        }?.activityInfo?.packageName
        return byLabel ?: DEFAULT_GAME_PKG
    }

    /** الحزمة اللي على الشاشة دلوقتي: النافذة النشطة، وإلا أعلى نافذة تطبيق، وإلا آخر حدث. */
    private fun currentPackage(): String? {
        var p: String? = null
        val root = rootInActiveWindow
        p = root?.packageName?.toString()
        @Suppress("DEPRECATION")
        root?.recycle()
        if (p == null || p == packageName) {
            try {
                val top = windows
                    .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                    .maxByOrNull { it.layer }
                val r = top?.root
                val q = r?.packageName?.toString()
                @Suppress("DEPRECATION")
                r?.recycle()
                if (q != null && q != packageName) p = q
            } catch (_: Throwable) {}
        }
        if (p == null || p == packageName) p = eventPkg
        return p
    }

    /** إشعار دائم عشان MIUI ما يجمّد الخدمة وهي في الخلفية. */
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("sgbot", "Summoners Helper", NotificationManager.IMPORTANCE_LOW)
            )
            val n = Notification.Builder(this, "sgbot")
                .setContentTitle("Summoners Helper")
                .setContentText("جاهز، هيشتغل أول ما تفتح اللعبة")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build()
            startForeground(1, n)
        } catch (e: Throwable) {
            log("مقدرتش أشغّل الإشعار الدائم: ${e.message}")
        }
    }

    // ---------- الأيقونة العايمة ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (overlay != null) { refreshOverlay(); return }
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = dp(46)
        val view = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs().getInt("ovx", 0)
            y = prefs().getInt("ovy", (dm.heightPixels * 0.55).toInt())
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (moved || Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        moved = true
                        lp.x = (startX + dx).toInt().coerceIn(0, dm.widthPixels - size)
                        lp.y = (startY + dy).toInt().coerceIn(0, dm.heightPixels - size)
                        try { wm.updateViewLayout(view, lp) } catch (_: Throwable) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs().edit().putInt("ovx", lp.x).putInt("ovy", lp.y).apply()
                    } else {
                        val now = !prefs().getBoolean("enabled", true)
                        prefs().edit().putBoolean("enabled", now).apply()
                        log(if (now) "البوت شغّال (من الأيقونة)" else "البوت اتوقف (من الأيقونة)")
                        refreshOverlay()
                    }
                }
            }
            true
        }
        try {
            wm.addView(view, lp)
            overlay = view
            overlayLp = lp
            refreshOverlay()
        } catch (e: Throwable) {
            log("مقدرتش أعرض الأيقونة: ${e.message}")
        }
    }

    private fun refreshOverlay() {
        val v = overlay ?: return
        val on = prefs().getBoolean("enabled", true)
        v.text = if (on) "ON" else "OFF"
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) Color.argb(200, 46, 160, 67) else Color.argb(200, 200, 50, 50))
            setStroke(dp(2), Color.WHITE)
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {}
        overlay = null
        overlayLp = null
    }

    // ---------- إعدادات ----------
    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun enabled() = ready && prefs().getBoolean("enabled", true)
    private fun optBuy() = prefs().getBoolean("buy", true)
    private fun optMonitor() = prefs().getBoolean("monitor", true)
    private fun optAch() = prefs().getBoolean("ach", true)
    private fun optGoldOnly() = prefs().getBoolean("goldonly", false)
    private fun optWarp() = prefs().getBoolean("warp", true)
    private fun optNext() = prefs().getBoolean("next", true)

    @Suppress("DEPRECATION")
    private fun acquireWake() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "sgbot:screen"
        ).also { it.acquire() }
    }

    private fun releaseWake() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Throwable) {}
        wakeLock = null
    }

    private fun resetState() {
        mode = Mode.IDLE
        adSawAway = false
        popupKey = null
        winFlowUntil = 0
        placeFlowUntil = 0
        mapScrolls = 0
        mapOpenPending = 0
        resetAch()
    }

    // ---------- التقاط الشاشة ----------
    private fun capture() {
        val t = SystemClock.elapsedRealtime()
        // الأندرويد بيرفض لو الالتقاط أسرع من مرة كل ~ثانية (كود 3)، فنحدّد المعدل بنفسنا
        if (t - lastCaptureAt < 1100) return
        if (busy) {
            if (t - busySince < 6000) return
            log("التقاط الشاشة علّق، بعيد المحاولة")   // watchdog: ممكن الـ callback ما يرجعش أبدًا
        }
        busy = true
        busySince = t
        lastCaptureAt = t
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var frame: Mat? = null
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    if (hw == null) { hb.close(); return }
                    val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                    hw.recycle()
                    hb.close()
                    sx = bmp.width / Detector.W.toFloat()
                    sy = bmp.height / Detector.H.toFloat()
                    frame = det.prepare(bmp)
                    bmp.recycle()
                    step(frame)
                } catch (e: Throwable) {
                    log("خطأ في المعالجة: ${e.message}")
                } finally {
                    frame?.release()
                    busy = false
                }
            }

            override fun onFailure(errorCode: Int) {
                busy = false
                // كود 3 = التقاط أسرع من اللازم، مش مشكلة حقيقية فمش بنسجّله
                if (errorCode != 3) log("فشل التقاط الشاشة (كود $errorCode)")
            }
        })
    }

    // ---------- المنطق الرئيسي ----------
    private fun step(f: Mat) {
        val now = SystemClock.elapsedRealtime()

        val achHdr = det.find(f, "ach_header", 0.80)

        // 1) أي عرض من التاجر أو المونيتور: زرار أحمر (No Thanks) على الشمال وزرار ملوّن على اليمين.
        //    بنكشفه بالشكل واللون مش بالنص، فيشتغل مع أي عرض أو أي نوع أحجار.
        val offer = det.findOffer(f)
        if (offer != null) {
            trackPopup("offer", now)
            if (mode == Mode.AD) {
                // نافذة العرض لسه ظاهرة بعد الضغط: يعني الضغطة ما اشتغلتش، نعيدها
                if (now - lastTap > 2500) {
                    tap(offer.right.x, offer.right.y)
                    adStart = now
                    log("مونيتور: الضغطة ما اشتغلتش، أعدتها")
                }
                return
            }
            if (now - lastTap < 1200 || now < offerCooldownUntil) return
            val isMonitor = det.find(f, "watch_video", 0.70) != null
            val hasCoin = det.find(f, "coin", 0.75) != null
            val stuck = now - popupSince > 8000               // العرض عالق (مثلاً رصيد مش كفاية)
            val wanted = if (isMonitor) optMonitor() else (optBuy() && (!optGoldOnly() || hasCoin))
            val accept = !stuck && wanted
            if (accept) {
                tap(offer.right.x, offer.right.y)
                offerCooldownUntil = now + 4000
                if (isMonitor) {
                    mode = Mode.AD
                    adStart = now
                    adSawAway = false
                    log("مونيتور: ضغطت Watch Video")
                } else {
                    log(if (hasCoin) "تاجر: اشتريت (ذهب)" else "تاجر: اشتريت")
                }
            } else {
                tap(offer.left.x, offer.left.y)
                offerCooldownUntil = now + 2000
                log(if (stuck) "عرض عالق: ضغطت No Thanks" else "ضغطت No Thanks")
            }
            return
        }
        popupKey = null

        // 2.5) قائمة المهام: نافذة الدنجن ونافذة "Entering New Map".
        //      لازم قبل OKAY لأن شريط اسم الدنجن الأخضر شبه زرار OKAY.
        if (queueActive()) {
            queueWatchdog()
            if (handleEnterDialog(f, now)) return
            if (handleDungeonPopup(f, now)) return
        }

        // 3) نافذة "You received" -> OKAY
        val okay = det.find(f, "okay", 0.80) ?: det.findBigGreenButton(f)
        if (okay != null) {
            if (now - lastTap < 1000) return
            tap(okay.x, okay.y)
            log("استلمت الجائزة (OKAY)")
            mode = Mode.IDLE
            cooldownUntil = now + 12_000
            return
        }

        // 4) نافذة الإنجازات
        if (achHdr != null) {
            handleAchievements(f, now)
            return
        } else {
            resetAch()
        }

        // 5) الخسارة: Time Warp ثم Return to Wave
        if (handleLoss(f, now)) return

        // 6) الفوز بالزعيم: Continue ثم اختيار الخريطة التالية
        if (handleWin(f, now)) return

        // 6.5) نهاية محاولة دنجن (You Defeated / You Died + Continue): لو زرار Continue ما اتعرفش بالصورة،
        //      نضغط أي زرار أخضر عريض بعد ما المحاولة تكون مشيت وقت كافي.
        if (queueActive() && TaskQueue.launched(this) && now - lastTap >= 1500 &&
            System.currentTimeMillis() - TaskQueue.launchedAt(this) > 20_000 &&
            TaskQueue.current(this)?.type == TaskType.DUNGEON
        ) {
            val g = det.findWideGreen(f)
            if (g != null) {
                tap(g.x, g.y)
                onAttemptFinished()
                log("دنجن: ضغطت Continue (نهاية المحاولة)")
                return
            }
        }

        // 7) شاشة اختيار الوحوش بعد التدفقين: Confirm
        //    لو Confirm لسه ظاهر بعد الضغطة (ساعات الضغطة بتضيع) بنعيدها كل ~2 ثانية.
        val inPlaceFlow = now < placeFlowUntil || (queueActive() && TaskQueue.launched(this))
        if (inPlaceFlow && now - lastTap >= 2000) {
            val confirm = det.find(f, "confirm_btn", 0.80)
            if (confirm != null) {
                val again = now - lastConfirmTap < 10_000
                tap(confirm.x, confirm.y)
                lastConfirmTap = now
                placeFlowUntil = now + 15_000
                log(if (again) "Confirm لسه ظاهر: أعدت الضغط" else "أكدت مكان الوحوش (Confirm)")
                return
            }
        }

        // 8) فيديو إعلان شغال: نستنى لحد ما يقفل. الإعلان بيخلّص لما شاشة اللعب ترجع،
        //    سواء ظهرت نافذة "You received" أو لأ (زي جوايز 2x Attack و 2x Coins).
        if (mode == Mode.AD) {
            val onGame = det.find(f, "trophy", 0.75) != null
            if (!onGame) {
                adSawAway = true
            } else if (adSawAway && now - adStart > 4_000) {
                log("الإعلان خلص")
                mode = Mode.IDLE
                adSawAway = false
                cooldownUntil = now + 6_000
                return
            } else if (!adSawAway && now - adStart > 25_000) {
                log("الإعلان ما بدأش، كمّلت")
                mode = Mode.IDLE
                return
            }
            if (now - adStart > 150_000) {
                log("الإعلان خد وقت طويل، ضغطت Back")
                performGlobalAction(GLOBAL_ACTION_BACK)
                mode = Mode.IDLE
                cooldownUntil = now + 5_000
            }
            return
        }

        // 9) شاشة اللعب العادية
        val trophy = det.find(f, "trophy", 0.75)
        if (trophy == null) return
        if (now < cooldownUntil || now - lastTap < 1200) return

        val sprite = det.find(f, "seller_idle", 0.72) ?: det.find(f, "monitor_idle", 0.72)
        if (sprite != null && now - lastSpriteTap > 4000) {
            tap(sprite.x, sprite.y)
            lastSpriteTap = now
            log("ضغطت على الشخصية الواقفة")
            return
        }

        // قائمة المهام: لو مفيش مهمة شغّالة دلوقتي، افتح شاشة الخرائط عشان نبدأ اللي بعدها
        if (queueActive() && !TaskQueue.launched(this) && TaskQueue.current(this) != null) {
            openMapScreen(trophy, now)
            return
        }

        if (optAch() && now - lastTrophyTap > 3_000 && det.hasAchievementBadge(f)) {
            tap(trophy.x, trophy.y)
            lastTrophyTap = now
            resetAch()
            log("فتحت الإنجازات")
        }
    }

    private fun trackPopup(key: String, now: Long) {
        if (popupKey != key) {
            popupKey = key
            popupSince = now
        }
    }

    // ---------- الخسارة ----------
    /** @return true لو الشاشة دي من تدفق الخسارة (سواء ضغطنا أو لأ). */
    private fun handleLoss(f: Mat, now: Long): Boolean {
        // نافذة Time Warp لازم تتفحص الأول، لأن شاشة الخسارة بتفضل ظاهرة باهتة وراها
        val returnTo = det.find(f, "return_to", 0.80)
        if (returnTo != null) {
            if (optWarp() && now - lastTap >= 1500) {
                tap(returnTo.x, returnTo.y)
                placeFlowUntil = now + 90_000
                log("خسارة: Return to Wave")
            }
            return true
        }
        val warp = det.find(f, "time_warp_btn", 0.80)
        if (warp != null) {
            if (optWarp() && now - lastTap >= 1500) {
                tap(warp.x, warp.y)
                log("خسارة: ضغطت Time Warp")
            }
            return true
        }
        return false
    }

    // ---------- الفوز ----------
    private fun handleWin(f: Mat, now: Long): Boolean {
        val mapHdr = det.find(f, "map_hdr", 0.80)
        if (mapHdr != null) {
            if (queueActive()) {
                handleQueueMap(f, now)
            } else if (optNext() && now < winFlowUntil) {
                handleMap(f, now)
            }
            return true
        }
        mapScrolls = 0

        val cont = det.find(f, "continue_btn", 0.80)
        if (cont != null) {
            val q = queueActive()
            if ((optNext() || q) && now - lastTap >= 1500) {
                tap(cont.x, cont.y)
                if (q) {
                    onAttemptFinished()
                    winFlowUntil = 0
                    log("فوز: ضغطت Continue")
                } else {
                    winFlowUntil = now + 120_000
                    log("فوز: ضغطت Continue")
                }
            }
            return true
        }
        return false
    }

    private fun handleMap(f: Mat, now: Long) {
        if (now - lastTap < 1200) return
        val news = det.findAll(f, "new_lbl", 0.75)
        // الأولوية لزرار Normal (العمود الشمال)، بعدين Expert، بعدين Heroic
        val pick = news.filter { it.x < 130 }.minByOrNull { it.y }
            ?: news.filter { it.x in 130..260 }.minByOrNull { it.y }
            ?: news.minByOrNull { it.y }
        if (pick != null) {
            tap(pick.x, pick.y + 26)          // الزرار تحت علامة NEW! بـ 26 بكسل
            placeFlowUntil = now + 90_000
            log("فوز: اخترت الخريطة الجديدة")
            return
        }
        when {
            mapScrolls < 8 -> { swipe(194, 700, 194, 380); mapScrolls++ }        // انزل في القائمة
            mapScrolls < 16 -> { swipe(194, 380, 194, 700); mapScrolls++ }       // اطلع
            else -> {
                val close = det.find(f, "map_close", 0.80)
                if (close != null) {
                    tap(close.x, close.y)
                    log("مفيش خريطة جديدة، قفلت القائمة")
                    winFlowUntil = 0
                    mapScrolls = 0
                }
            }
        }
    }

    // ---------- قائمة المهام ----------
    private fun queueActive() = ready && prefs().getBoolean("q_on", false)

    private fun finishTask(task: GameTask, note: String) {
        TaskQueue.update(this) { l ->
            l.firstOrNull { it.id == task.id }?.let { it.done = true; it.note = note }
        }
        TaskQueue.setLaunched(this, false)
        log("خلصت مهمة: ${task.title()} ($note)")
        qTapTries = 0
        ocrTries = 0
        lvStreak = 0
        resetQScroll()
    }

    private fun resetQScroll() {
        qScrolls = 0
        qDirDown = true
        qFlips = 0
        qPrevSig?.release()
        qPrevSig = null
    }

    /** مهمة اتغيّرت: صفّر العدادات. */
    private fun syncTask(task: GameTask) {
        if (qTaskId != task.id) {
            qTaskId = task.id
            qTapTries = 0
            ocrTries = 0
            lvStreak = 0
            resetQScroll()
        }
    }

    /** الفوز (Continue) بيعني إن المحاولة الحالية خلصت. */
    private fun onAttemptFinished() {
        val task = TaskQueue.current(this)
        if (task == null || !TaskQueue.launched(this)) return
        when (task.type) {
            TaskType.MAP -> finishTask(task, "فاز")
            TaskType.DUNGEON -> {
                // الليفل الجديد بيتقرا من نافذة Free Challenge اللي بترجع بعد Continue (الخسارة مش بترفعه)
                TaskQueue.setLaunched(this, false)
                lvStreak = 0
                ocrTries = 0
                log("دنجن: المحاولة خلصت")
            }
        }
    }

    /** لو مهمة عدّى عليها وقت طويل جدًا من غير ما تخلص. */
    private fun queueWatchdog() {
        if (!TaskQueue.launched(this)) return
        val task = TaskQueue.current(this) ?: return
        val age = System.currentTimeMillis() - TaskQueue.launchedAt(this)
        when (task.type) {
            TaskType.MAP -> if (age > 6 * 3600_000L) finishTask(task, "عدّى 6 ساعات، اتخطّت")
            TaskType.DUNGEON -> if (age > 30 * 60_000L) {
                TaskQueue.setLaunched(this, false)
                log("دنجن: المحاولة خدت أكتر من 30 دقيقة، هعيد")
            }
        }
    }

    /**
     * نافذة "Entering New Map / Are you sure": طول ما قائمة المهام شغّالة بنضغط Enter (الأحمر).
     * بنعرفها بأي واحدة من: عنوانها، أو صورة زرار Enter، أو شكل الزرارين (أحمر على الشمال + أخضر Nope على اليمين).
     * وبنعيد الضغط كل ثانية وشوية لحد ما تختفي.
     */
    private fun handleEnterDialog(f: Mat, now: Long): Boolean {
        val hdr = det.find(f, "entering_hdr", 0.80) != null
        val tplEnter = det.find(f, "enter_btn", 0.80)
        val colorEnter = det.findEnterDialog(f)
        if (!hdr && colorEnter == null && tplEnter == null) return false
        if (now - lastTap < 1200) return true
        val target = colorEnter ?: tplEnter ?: Hit(110, 506, 1.0)
        tap(target.x, target.y)
        placeFlowUntil = now + 90_000
        log("أكدت دخول الخريطة الجديدة (Enter)")
        return true
    }

    /** نافذة الدنجن (Sweep / Free Challenge): نقرا الليفل والمفاتيح ونقرر نلعب ولا نخلّص المهمة. */
    private fun handleDungeonPopup(f: Mat, now: Long): Boolean {
        val free = det.find(f, "free_btn", 0.85) ?: return false
        det.find(f, "sweep_btn", 0.85) ?: return false
        if (now - lastTap < 1200) return true
        val task = TaskQueue.current(this)
        if (task == null || task.type != TaskType.DUNGEON) {
            tap(357, 258)                                   // X بتاع النافذة
            log("قفلت نافذة الدنجن (مش في المهمة الحالية)")
            return true
        }
        syncTask(task)
        if (TaskQueue.launched(this) && System.currentTimeMillis() - TaskQueue.launchedAt(this) < 8_000) return true

        // Free Challenge مش بتستهلك مفاتيح (Sweep هو اللي بيستهلكها)، فالمفاتيح مش شرط. بنقرا الليفل بس.
        // القراءة بتتأكد: لازم نفس الرقم مرتين ورا بعض (3 مرات لو الرقم وصل للهدف)، والرقم لازم يكون
        // منطقي (نفس الليفل اللي فات أو اللي بعده). أي قراءة بعيدة بتتهمل.
        if (now - lastOcrAt < 700) return true          // مش بنقرا أسرع من كده (النافذة بتظهر بأنيميشن)
        lastOcrAt = now
        if (ocrTries == 0) ocrStartAt = now
        val level = ocr.readLevel(det, f)
        val known = task.knownLevel
        val plausible = level != null && (known <= 0 || level in known..(known + 2))
        if (plausible) {
            if (level == lvStreakVal) lvStreak++ else { lvStreakVal = level!!; lvStreak = 1 }
        } else {
            lvStreak = 0
        }
        val need = if (plausible && task.target > 0 && level!! >= task.target) 3 else 2
        if (lvStreak < need) {
            ocrTries++
            if (ocrTries <= 8 || now - ocrStartAt < 10_000) {
                log("بتأكد من الليفل ($ocrTries): قريت ${level ?: "؟"}")
                return true
            }
            finishTask(task, "مقدرتش أقرا الليفل بثقة")
            tap(357, 258)
            return true
        }
        val lv = lvStreakVal
        if (lv != known) {
            TaskQueue.update(this) { l -> l.firstOrNull { it.id == task.id }?.knownLevel = lv }
        }

        if (task.target > 0 && lv >= task.target) {
            finishTask(task, "وصل لليفل $lv")
            tap(357, 258)
            return true
        }
        if (task.plays >= 60) {
            finishTask(task, "وصل الحد الأقصى للمحاولات")
            tap(357, 258)
            return true
        }

        tap(free.x, free.y)
        TaskQueue.update(this) { l -> l.firstOrNull { it.id == task.id }?.let { it.plays++ } }
        TaskQueue.setLaunched(this, true)
        placeFlowUntil = now + 90_000
        lvStreak = 0
        ocrTries = 0
        log("دنجن: Free Challenge (${Catalog.label(task.key)}، ليفل $lv)")
        return true
    }

    /** من شاشة اللعب: افتح Select Map بالضغط على لوحة WAVE اللي فوق أيقونات الكأس والإعدادات. */
    private fun openMapScreen(trophy: Hit, now: Long) {
        if (mapOpenPending != 0L && now - mapOpenPending < 4000) return
        tap(trophy.x - 12, trophy.y - 39)
        mapOpenPending = now
        log("فتحت شاشة الخرائط (لوحة WAVE)")
    }

    /** شاشة Select Map وفيه قائمة مهام شغّالة: روح للتبويب والصف المطلوب واضغط. */
    private fun handleQueueMap(f: Mat, now: Long) {
        if (mapOpenPending != 0L) {
            mapOpenPending = 0
        }
        if (now - lastTap < 1300) return

        val task = TaskQueue.current(this)
        if (task == null) {
            // القائمة خلصت
            prefs().edit().putBoolean("q_on", false).apply()
            TaskQueue.setLaunched(this, false)
            log("قائمة المهام خلصت")
            det.find(f, "map_close", 0.80)?.let { tap(it.x, it.y) }
            return
        }
        syncTask(task)

        // المهمة بدأت من لحظات: استنى الشاشة تتغيّر. لو لسه واقفين هنا بعد 8 ثواني، نعيد.
        if (TaskQueue.launched(this)) {
            if (System.currentTimeMillis() - TaskQueue.launchedAt(this) < 8_000) return
            TaskQueue.setLaunched(this, false)
            log("لسه في شاشة الخرائط بعد الضغط، هعيد")
        }

        val wantTab = if (task.type == TaskType.MAP) 0 else 1
        val tab = det.tab(f)
        if (tab != wantTab) {
            tap(if (wantTab == 0) 64 else 194, 109)
            resetQScroll()
            return
        }

        val row = det.find(f, task.key, 0.87)
        if (row == null) {
            scrollSearch(f, task)
            return
        }
        qScrolls = 0; qFlips = 0

        // الصف قريب أوي من الحافة: حرّكه للنص الأول
        // (الحدود دي بتسيب مكان للزرار تحت الاسم في المابات، وما بتعلّقش لما القائمة توصل لآخرها)
        val top = if (task.type == TaskType.MAP) 300 else 235
        val bottom = if (task.type == TaskType.MAP) 670 else 735
        if (row.y < top) { swipe(194, 420, 194, 600); return }
        if (row.y > bottom) { swipe(194, 650, 194, 450); return }

        qTapTries++
        if (qTapTries > 6) {
            finishTask(task, "متخطّاة: مقدرتش أفتحها (مقفولة؟)")
            return
        }
        if (task.type == TaskType.MAP) {
            val bx = Catalog.diffX[task.diff]
            val by = row.y + 91
            if (!det.buttonEnabled(f, bx, by)) {
                finishTask(task, "متخطّاة: ${Catalog.diffNames[task.diff]} مقفول")
                return
            }
            tap(bx, by)
            TaskQueue.setLaunched(this, true)
            placeFlowUntil = now + 90_000
            log("بدأت: ${task.title()}")
        } else {
            tap(200, row.y)                                  // تفتح نافذة الدنجن
            log("فتحت الدنجن: ${Catalog.label(task.key)}")
        }
    }

    /** دوّر على الصف بالسحب: نازل لحد النهاية، وبعدين طالع. */
    private fun scrollSearch(f: Mat, task: GameTask) {
        val sig = det.panelSignature(f)
        val unchanged = qPrevSig?.let { det.sameSignature(it, sig) } ?: false
        qPrevSig?.release()
        qPrevSig = sig
        if (unchanged && qScrolls > 0) {
            qFlips++
            qDirDown = !qDirDown
        }
        qScrolls++
        if (qFlips >= 2 || qScrolls > 30) {
            finishTask(task, "متخطّاة: مش لاقي الصف في القائمة")
            return
        }
        if (qDirDown) swipe(194, 700, 194, 380) else swipe(194, 380, 194, 700)
    }

    // ---------- الإنجازات ----------
    private fun resetAch() {
        achPhase = 0
        achSwipes = 0
        achPhaseSwipes = 0
        prevSig?.release()
        prevSig = null
    }

    /**
     * سحب القائمة مرة واحدة في كل اتجاه:
     * المرحلة 0: اطلع لأعلى القائمة. المرحلة 1: انزل صفحة صفحة واستلم أي جايزة. بعدها اقفل.
     * بنستنى 1.5 ثانية بعد كل سحبة عشان القائمة تستقر قبل ما نقارن.
     */
    private fun handleAchievements(f: Mat, now: Long) {
        if (now - lastTap < 500) return

        val claims = det.claimButtons(f)
        if (claims.isNotEmpty()) {
            tap(claims[0].x, claims[0].y)
            log("استلمت إنجاز")
            return
        }

        val cur = det.panelSignature(f)
        val unchanged = prevSig?.let { det.sameSignature(it, cur) } ?: false
        prevSig?.release()
        prevSig = cur

        if (achPhase == 0) {
            if (unchanged || achPhaseSwipes >= 3) {
                achPhase = 1                        // وصلنا لفوق، ابدأ النزول
                achPhaseSwipes = 1
                swipe(194, 760, 194, 130, 160)
            } else {
                achPhaseSwipes++
                swipe(194, 130, 194, 760, 160)           // اطلع لأعلى القائمة
            }
            return
        }
        if (achPhase == 1) {
            if (!unchanged && achPhaseSwipes < 5) {
                achPhaseSwipes++
                swipe(194, 760, 194, 130, 160)           // الصفحة اللي بعدها
                return
            }
            achPhase = 2                            // وصلنا لتحت
        }

        // المرحلة 2: خلصنا، اقفل النافذة وترجع تفتحها أول ما تظهر العلامة الزرقاء تاني
        val close = det.find(f, "ach_close", 0.80)
        if (close != null) {
            tap(close.x, close.y)
            lastTrophyTap = now
            log("قفلت الإنجازات")
            resetAch()
        }
    }

    // ---------- لمس ----------
    private fun tap(x: Int, y: Int) {
        lastTap = SystemClock.elapsedRealtime()
        val p = Path().apply { moveTo(x * sx, y * sy) }
        dispatch(GestureDescription.StrokeDescription(p, 0, 110))
    }

    private fun swipe(x0: Int, y0: Int, x1: Int, y1: Int, dur: Long = 350) {
        lastTap = SystemClock.elapsedRealtime()
        val p = Path().apply {
            moveTo(x0 * sx, y0 * sy)
            lineTo(x1 * sx, y1 * sy)
        }
        dispatch(GestureDescription.StrokeDescription(p, 0, dur))
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        main.post { dispatchGesture(g, null, null) }
    }
}

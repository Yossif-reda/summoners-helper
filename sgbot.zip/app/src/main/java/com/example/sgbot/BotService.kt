package com.example.sgbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityWindowInfo
import org.opencv.android.OpenCVLoader
import org.opencv.core.Mat
import java.util.concurrent.Executor

class BotService : AccessibilityService() {

    companion object {
        private const val TAG = "SGBot"
        const val PREFS = "sgbot"
        const val DEFAULT_GAME_PKG = "com.pixio.google.mtd"

        /** true لما البوت مفعّل واللعبة هي الشاشة الحالية. */
        @Volatile var gameActive = false
        @Volatile var gamePkg = DEFAULT_GAME_PKG
        private val logLines = ArrayDeque<String>()

        @Synchronized
        fun log(msg: String) {
            Log.i(TAG, msg)
            val t = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            logLines.addFirst("$t  $msg")
            while (logLines.size > 60) logLines.removeLast()
        }

        @Synchronized
        fun recentLog(): String = logLines.joinToString("\n")
    }

    private enum class Mode { IDLE, AD }

    private val main = Handler(Looper.getMainLooper())
    private val workerThread = HandlerThread("sgbot-worker").also { it.start() }
    private val worker = Handler(workerThread.looper)
    private val executor = Executor { worker.post(it) }

    private lateinit var det: Detector
    private var ready = false
    private var busy = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var eventPkg: String? = null      // آخر حزمة وصلت من أحداث النوافذ
    private var overlay: TextView? = null     // الأيقونة العايمة (بتظهر جوه اللعبة بس)
    private var overlayLp: WindowManager.LayoutParams? = null

    // حالة الـ state machine
    private var mode = Mode.IDLE
    private var adStart = 0L
    private var lastTap = 0L
    private var cooldownUntil = 0L        // بعد ما نخلص تاجر/مونيتور نتجاهل الشخصية وهي ماشية
    private var lastSpriteTap = 0L
    private var lastTrophyTap = 0L
    private var popupKey: String? = null
    private var popupSince = 0L
    private var offerCooldownUntil = 0L
    private var busySince = 0L
    private var lastCaptureAt = 0L
    private var adSawAway = false          // الإعلان ظهر فعلًا (شاشة اللعب اختفت)
    private var achPhaseSwipes = 0
    private var lastFgLogged: String? = null

    // تدفق الفوز/الخسارة: بنأكد على شاشة اختيار الوحوش بس لو إحنا اللي بدأنا التدفق
    private var winFlowUntil = 0L
    private var placeFlowUntil = 0L
    private var mapScrolls = 0

    // حالة نافذة الإنجازات
    private var achPhase = 0              // 0: اسحب لأعلى القائمة، 1: انزل لآخرها، 2: اقفل
    private var achSwipes = 0
    private var prevSig: Mat? = null

    private var sx = 1f
    private var sy = 1f

    private val loop = object : Runnable {
        override fun run() {
            try {
                val pkgNow = currentPackage()
                if (pkgNow != lastFgLogged) {
                    lastFgLogged = pkgNow
                    log("الشاشة الحالية: ${pkgNow ?: "؟"}")
                }
                val inGame = pkgNow == gamePkg
                if (inGame) showOverlay() else hideOverlay()

                if (inGame && enabled()) {
                    if (!gameActive) {
                        gameActive = true
                        log("اللعبة اتفتحت، البوت بدأ")
                    }
                    acquireWake()
                    capture()
                } else {
                    if (gameActive) {
                        gameActive = false
                        resetState()
                        log(if (inGame) "البوت اتوقف" else "اللعبة مش على الشاشة، البوت مستني")
                    }
                    releaseWake()
                }
            } catch (e: Throwable) {
                log("خطأ: ${e.message}")
            }
            main.postDelayed(this, 1000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        if (!OpenCVLoader.initLocal()) {
            log("OpenCV مش راضي يشتغل")
            return
        }
        det = Detector(this)
        gamePkg = resolveGamePackage()
        ready = true
        startKeepAlive()
        log("الخدمة اتوصلت. اللعبة: $gamePkg")
        main.post(loop)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val p = event.packageName?.toString() ?: return
        // نتجاهل نافذة النظام ولوحة المفاتيح: الشاشة الحقيقية هي اللي تحتهم
        if (p == "com.android.systemui" || p.contains("inputmethod") || p == packageName) return
        eventPkg = p
        // رد فعل فوري لما اللعبة تفتح، من غير ما نستنى الدورة الجاية
        if (ready) {
            main.removeCallbacks(loop)
            main.post(loop)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        hideOverlay()
        releaseWake()
        gameActive = false
        workerThread.quitSafely()
        super.onDestroy()
    }

    // ---------- اكتشاف اللعبة ----------
    private fun resolveGamePackage(): String {
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
        if (apps.any { it.activityInfo.packageName == DEFAULT_GAME_PKG }) return DEFAULT_GAME_PKG
        // لو الحزمة الافتراضية مش موجودة: دوّر بالاسم (ونستثني تطبيقنا هو)
        val byLabel = apps.firstOrNull {
            it.activityInfo.packageName != packageName &&
                it.loadLabel(pm).toString().contains("summoner", ignoreCase = true)
        }?.activityInfo?.packageName
        return byLabel ?: DEFAULT_GAME_PKG
    }

    /** الحزمة اللي على الشاشة دلوقتي: النافذة النشطة، وإلا أعلى نافذة تطبيق، وإلا آخر حدث. */
    private fun currentPackage(): String? {
        var p: String? = null
        val root = rootInActiveWindow
        p = root?.packageName?.toString()
        @Suppress("DEPRECATION")
        root?.recycle()
        if (p == null || p == packageName) {
            try {
                val top = windows
                    .filter { it.type == AccessibilityWindowInfo.TYPE_APPLICATION }
                    .maxByOrNull { it.layer }
                val r = top?.root
                val q = r?.packageName?.toString()
                @Suppress("DEPRECATION")
                r?.recycle()
                if (q != null && q != packageName) p = q
            } catch (_: Throwable) {}
        }
        if (p == null || p == packageName) p = eventPkg
        return p
    }

    /** إشعار دائم عشان MIUI ما يجمّد الخدمة وهي في الخلفية. */
    private fun startKeepAlive() {
        try {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel("sgbot", "Summoners Helper", NotificationManager.IMPORTANCE_LOW)
            )
            val n = Notification.Builder(this, "sgbot")
                .setContentTitle("Summoners Helper")
                .setContentText("جاهز، هيشتغل أول ما تفتح اللعبة")
                .setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setOngoing(true)
                .build()
            startForeground(1, n)
        } catch (e: Throwable) {
            log("مقدرتش أشغّل الإشعار الدائم: ${e.message}")
        }
    }

    // ---------- الأيقونة العايمة ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun showOverlay() {
        if (overlay != null) { refreshOverlay(); return }
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val size = dp(46)
        val view = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(Color.WHITE)
        }
        val dm = resources.displayMetrics
        val lp = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = prefs().getInt("ovx", 0)
            y = prefs().getInt("ovy", (dm.heightPixels * 0.55).toInt())
        }
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0; var moved = false
        view.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (moved || Math.abs(dx) > dp(8) || Math.abs(dy) > dp(8)) {
                        moved = true
                        lp.x = (startX + dx).toInt().coerceIn(0, dm.widthPixels - size)
                        lp.y = (startY + dy).toInt().coerceIn(0, dm.heightPixels - size)
                        try { wm.updateViewLayout(view, lp) } catch (_: Throwable) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (moved) {
                        prefs().edit().putInt("ovx", lp.x).putInt("ovy", lp.y).apply()
                    } else {
                        val now = !prefs().getBoolean("enabled", true)
                        prefs().edit().putBoolean("enabled", now).apply()
                        log(if (now) "البوت شغّال (من الأيقونة)" else "البوت اتوقف (من الأيقونة)")
                        refreshOverlay()
                    }
                }
            }
            true
        }
        try {
            wm.addView(view, lp)
            overlay = view
            overlayLp = lp
            refreshOverlay()
        } catch (e: Throwable) {
            log("مقدرتش أعرض الأيقونة: ${e.message}")
        }
    }

    private fun refreshOverlay() {
        val v = overlay ?: return
        val on = prefs().getBoolean("enabled", true)
        v.text = if (on) "ON" else "OFF"
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (on) Color.argb(200, 46, 160, 67) else Color.argb(200, 200, 50, 50))
            setStroke(dp(2), Color.WHITE)
        }
    }

    private fun hideOverlay() {
        val v = overlay ?: return
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (_: Throwable) {}
        overlay = null
        overlayLp = null
    }

    // ---------- إعدادات ----------
    private fun prefs() = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun enabled() = ready && prefs().getBoolean("enabled", true)
    private fun optBuy() = prefs().getBoolean("buy", true)
    private fun optMonitor() = prefs().getBoolean("monitor", true)
    private fun optAch() = prefs().getBoolean("ach", true)
    private fun optGoldOnly() = prefs().getBoolean("goldonly", false)
    private fun optWarp() = prefs().getBoolean("warp", true)
    private fun optNext() = prefs().getBoolean("next", true)

    @Suppress("DEPRECATION")
    private fun acquireWake() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(
            PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
            "sgbot:screen"
        ).also { it.acquire() }
    }

    private fun releaseWake() {
        try { if (wakeLock?.isHeld == true) wakeLock?.release() } catch (_: Throwable) {}
        wakeLock = null
    }

    private fun resetState() {
        mode = Mode.IDLE
        adSawAway = false
        popupKey = null
        winFlowUntil = 0
        placeFlowUntil = 0
        mapScrolls = 0
        resetAch()
    }

    // ---------- التقاط الشاشة ----------
    private fun capture() {
        val t = SystemClock.elapsedRealtime()
        // الأندرويد بيرفض لو الالتقاط أسرع من مرة كل ~ثانية (كود 3)، فنحدّد المعدل بنفسنا
        if (t - lastCaptureAt < 1100) return
        if (busy) {
            if (t - busySince < 6000) return
            log("التقاط الشاشة علّق، بعيد المحاولة")   // watchdog: ممكن الـ callback ما يرجعش أبدًا
        }
        busy = true
        busySince = t
        lastCaptureAt = t
        takeScreenshot(Display.DEFAULT_DISPLAY, executor, object : TakeScreenshotCallback {
            override fun onSuccess(result: ScreenshotResult) {
                var frame: Mat? = null
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    if (hw == null) { hb.close(); return }
                    val bmp = hw.copy(Bitmap.Config.ARGB_8888, false)
                    hw.recycle()
                    hb.close()
                    sx = bmp.width / Detector.W.toFloat()
                    sy = bmp.height / Detector.H.toFloat()
                    frame = det.prepare(bmp)
                    bmp.recycle()
                    step(frame)
                } catch (e: Throwable) {
                    log("خطأ في المعالجة: ${e.message}")
                } finally {
                    frame?.release()
                    busy = false
                }
            }

            override fun onFailure(errorCode: Int) {
                busy = false
                // كود 3 = التقاط أسرع من اللازم، مش مشكلة حقيقية فمش بنسجّله
                if (errorCode != 3) log("فشل التقاط الشاشة (كود $errorCode)")
            }
        })
    }

    // ---------- المنطق الرئيسي ----------
    private fun step(f: Mat) {
        val now = SystemClock.elapsedRealtime()

        val okay = det.find(f, "okay", 0.80) ?: det.findBigGreenButton(f)
        val achHdr = det.find(f, "ach_header", 0.80)

        // 1) أي عرض من التاجر أو المونيتور: زرار أحمر (No Thanks) على الشمال وزرار ملوّن على اليمين.
        //    بنكشفه بالشكل واللون مش بالنص، فيشتغل مع أي عرض أو أي نوع أحجار.
        val offer = det.findOffer(f)
        if (offer != null) {
            trackPopup("offer", now)
            if (mode == Mode.AD) return                       // الإعلان لسه بيتحمّل
            if (now - lastTap < 1200 || now < offerCooldownUntil) return
            val isMonitor = det.find(f, "watch_video", 0.70) != null
            val hasCoin = det.find(f, "coin", 0.75) != null
            val stuck = now - popupSince > 8000               // العرض عالق (مثلاً رصيد مش كفاية)
            val wanted = if (isMonitor) optMonitor() else (optBuy() && (!optGoldOnly() || hasCoin))
            val accept = !stuck && wanted
            if (accept) {
                tap(offer.right.x, offer.right.y)
                offerCooldownUntil = now + 4000
                if (isMonitor) {
                    mode = Mode.AD
                    adStart = now
                    adSawAway = false
                    log("مونيتور: ضغطت Watch Video")
                } else {
                    log(if (hasCoin) "تاجر: اشتريت (ذهب)" else "تاجر: اشتريت")
                }
            } else {
                tap(offer.left.x, offer.left.y)
                offerCooldownUntil = now + 2000
                log(if (stuck) "عرض عالق: ضغطت No Thanks" else "ضغطت No Thanks")
            }
            return
        }
        popupKey = null

        // 3) نافذة "You received" -> OKAY
        if (okay != null) {
            if (now - lastTap < 1000) return
            tap(okay.x, okay.y)
            log("استلمت الجائزة (OKAY)")
            mode = Mode.IDLE
            cooldownUntil = now + 12_000
            return
        }

        // 4) نافذة الإنجازات
        if (achHdr != null) {
            handleAchievements(f, now)
            return
        } else {
            resetAch()
        }

        // 5) الخسارة: Time Warp ثم Return to Wave
        if (handleLoss(f, now)) return

        // 6) الفوز بالزعيم: Continue ثم اختيار الخريطة التالية
        if (handleWin(f, now)) return

        // 7) شاشة اختيار الوحوش بعد التدفقين: Confirm
        if (now < placeFlowUntil && now - lastTap >= 1500) {
            val confirm = det.find(f, "confirm_btn", 0.80)
            if (confirm != null) {
                tap(confirm.x, confirm.y)
                placeFlowUntil = 0
                log("أكدت مكان الوحوش (Confirm)")
                return
            }
        }

        // 8) فيديو إعلان شغال: نستنى لحد ما يقفل. الإعلان بيخلّص لما شاشة اللعب ترجع،
        //    سواء ظهرت نافذة "You received" أو لأ (زي جوايز 2x Attack و 2x Coins).
        if (mode == Mode.AD) {
            val onGame = det.find(f, "trophy", 0.75) != null
            if (!onGame) {
                adSawAway = true
            } else if (adSawAway && now - adStart > 4_000) {
                log("الإعلان خلص")
                mode = Mode.IDLE
                adSawAway = false
                cooldownUntil = now + 6_000
                return
            } else if (!adSawAway && now - adStart > 25_000) {
                log("الإعلان ما بدأش، كمّلت")
                mode = Mode.IDLE
                return
            }
            if (now - adStart > 150_000) {
                log("الإعلان خد وقت طويل، ضغطت Back")
                performGlobalAction(GLOBAL_ACTION_BACK)
                mode = Mode.IDLE
                cooldownUntil = now + 5_000
            }
            return
        }

        // 9) شاشة اللعب العادية
        val trophy = det.find(f, "trophy", 0.75) ?: return
        if (now < cooldownUntil || now - lastTap < 1200) return

        val sprite = det.find(f, "seller_idle", 0.72) ?: det.find(f, "monitor_idle", 0.72)
        if (sprite != null && now - lastSpriteTap > 4000) {
            tap(sprite.x, sprite.y)
            lastSpriteTap = now
            log("ضغطت على الشخصية الواقفة")
            return
        }

        if (optAch() && now - lastTrophyTap > 4_000 && det.hasAchievementBadge(f)) {
            tap(trophy.x, trophy.y)
            lastTrophyTap = now
            resetAch()
            log("فتحت الإنجازات")
        }
    }

    private fun trackPopup(key: String, now: Long) {
        if (popupKey != key) {
            popupKey = key
            popupSince = now
        }
    }

    // ---------- الخسارة ----------
    /** @return true لو الشاشة دي من تدفق الخسارة (سواء ضغطنا أو لأ). */
    private fun handleLoss(f: Mat, now: Long): Boolean {
        // نافذة Time Warp لازم تتفحص الأول، لأن شاشة الخسارة بتفضل ظاهرة باهتة وراها
        val returnTo = det.find(f, "return_to", 0.80)
        if (returnTo != null) {
            if (optWarp() && now - lastTap >= 1500) {
                tap(returnTo.x, returnTo.y)
                placeFlowUntil = now + 90_000
                log("خسارة: Return to Wave")
            }
            return true
        }
        val warp = det.find(f, "time_warp_btn", 0.80)
        if (warp != null) {
            if (optWarp() && now - lastTap >= 1500) {
                tap(warp.x, warp.y)
                log("خسارة: ضغطت Time Warp")
            }
            return true
        }
        return false
    }

    // ---------- الفوز ----------
    private fun handleWin(f: Mat, now: Long): Boolean {
        val mapHdr = det.find(f, "map_hdr", 0.80)
        if (mapHdr != null) {
            if (optNext() && now < winFlowUntil) handleMap(f, now)
            return true
        }
        mapScrolls = 0

        val cont = det.find(f, "continue_btn", 0.80)
        if (cont != null) {
            if (optNext() && now - lastTap >= 1500) {
                tap(cont.x, cont.y)
                winFlowUntil = now + 120_000
                log("فوز: ضغطت Continue")
            }
            return true
        }
        return false
    }

    private fun handleMap(f: Mat, now: Long) {
        if (now - lastTap < 1200) return
        val news = det.findAll(f, "new_lbl", 0.75)
        // الأولوية لزرار Normal (العمود الشمال)، بعدين Expert، بعدين Heroic
        val pick = news.filter { it.x < 130 }.minByOrNull { it.y }
            ?: news.filter { it.x in 130..260 }.minByOrNull { it.y }
            ?: news.minByOrNull { it.y }
        if (pick != null) {
            tap(pick.x, pick.y + 26)          // الزرار تحت علامة NEW! بـ 26 بكسل
            placeFlowUntil = now + 90_000
            log("فوز: اخترت الخريطة الجديدة")
            return
        }
        when {
            mapScrolls < 8 -> { swipe(194, 700, 194, 380); mapScrolls++ }        // انزل في القائمة
            mapScrolls < 16 -> { swipe(194, 380, 194, 700); mapScrolls++ }       // اطلع
            else -> {
                val close = det.find(f, "map_close", 0.80)
                if (close != null) {
                    tap(close.x, close.y)
                    log("مفيش خريطة جديدة، قفلت القائمة")
                    winFlowUntil = 0
                    mapScrolls = 0
                }
            }
        }
    }

    // ---------- الإنجازات ----------
    private fun resetAch() {
        achPhase = 0
        achSwipes = 0
        achPhaseSwipes = 0
        prevSig?.release()
        prevSig = null
    }

    /**
     * سحب القائمة مرة واحدة في كل اتجاه:
     * المرحلة 0: اطلع لأعلى القائمة. المرحلة 1: انزل صفحة صفحة واستلم أي جايزة. بعدها اقفل.
     * بنستنى 1.5 ثانية بعد كل سحبة عشان القائمة تستقر قبل ما نقارن.
     */
    private fun handleAchievements(f: Mat, now: Long) {
        if (now - lastTap < 1000) return

        val claims = det.claimButtons(f)
        if (claims.isNotEmpty()) {
            tap(claims[0].x, claims[0].y)
            log("استلمت إنجاز")
            return
        }

        val cur = det.panelSignature(f)
        val unchanged = prevSig?.let { det.sameSignature(it, cur) } ?: false
        prevSig?.release()
        prevSig = cur

        if (achPhase == 0) {
            if (unchanged || achPhaseSwipes >= 5) {
                achPhase = 1                        // وصلنا لفوق، ابدأ النزول
                achPhaseSwipes = 1
                swipe(194, 720, 194, 220)
            } else {
                achPhaseSwipes++
                swipe(194, 220, 194, 720)           // اطلع لأعلى القائمة
            }
            return
        }
        if (achPhase == 1) {
            if (!unchanged && achPhaseSwipes < 8) {
                achPhaseSwipes++
                swipe(194, 720, 194, 220)           // الصفحة اللي بعدها
                return
            }
            achPhase = 2                            // وصلنا لتحت
        }

        // المرحلة 2: خلصنا، اقفل النافذة وترجع تفتحها أول ما تظهر العلامة الزرقاء تاني
        val close = det.find(f, "ach_close", 0.80)
        if (close != null) {
            tap(close.x, close.y)
            lastTrophyTap = now
            log("قفلت الإنجازات")
            resetAch()
        }
    }

    // ---------- لمس ----------
    private fun tap(x: Int, y: Int) {
        lastTap = SystemClock.elapsedRealtime()
        val p = Path().apply { moveTo(x * sx, y * sy) }
        dispatch(GestureDescription.StrokeDescription(p, 0, 70))
    }

    private fun swipe(x0: Int, y0: Int, x1: Int, y1: Int) {
        lastTap = SystemClock.elapsedRealtime()
        val p = Path().apply {
            moveTo(x0 * sx, y0 * sy)
            lineTo(x1 * sx, y1 * sy)
        }
        dispatch(GestureDescription.StrokeDescription(p, 0, 350))
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription) {
        val g = GestureDescription.Builder().addStroke(stroke).build()
        main.post { dispatchGesture(g, null, null) }
    }
}

package com.example.sgbot

import android.content.Context
import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfByte
import org.opencv.core.MatOfPoint
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgcodecs.Imgcodecs
import org.opencv.imgproc.Imgproc

/** مكان اكتشاف (المركز) في فراغ الإحداثيات المرجعي 388x848. */
data class Hit(val x: Int, val y: Int, val score: Double)

/** نافذة عرض (تاجر/مونيتور): زرار الرفض على الشمال وزرار القبول على اليمين. */
data class Offer(val left: Hit, val right: Hit)

/**
 * كل الـ templates اتقصّت من فيديوهات اللعبة بمقاس 388x848،
 * فنصغّر أي screenshot لنفس المقاس قبل المطابقة، وبعدين نرجّع الإحداثيات للمقاس الحقيقي.
 */
class Detector(ctx: Context) {

    companion object {
        const val W = 388
        const val H = 848
    }

    private val tpl = HashMap<String, Mat>()

    // منطقة البحث لكل template: x0, y0, x1, y1
    private val roi = mapOf(
        "watch_video" to intArrayOf(0, 420, 388, 540),
        "coin" to intArrayOf(180, 420, 388, 540),
        "okay" to intArrayOf(40, 430, 350, 530),
        "seller_idle" to intArrayOf(230, 600, 388, 780),
        "monitor_idle" to intArrayOf(230, 600, 388, 780),
        "trophy" to intArrayOf(280, 50, 388, 130),
        "ach_header" to intArrayOf(60, 40, 330, 120),
        "ach_close" to intArrayOf(300, 40, 388, 120),
        // الفوز / الخسارة
        "continue_btn" to intArrayOf(40, 560, 350, 700),
        "map_hdr" to intArrayOf(100, 30, 300, 90),
        "map_close" to intArrayOf(320, 30, 388, 100),
        "new_lbl" to intArrayOf(20, 300, 388, 820),
        "time_warp_btn" to intArrayOf(10, 560, 200, 700),
        "return_to" to intArrayOf(200, 500, 388, 600),
        "confirm_btn" to intArrayOf(100, 770, 290, 848),
        // قائمة المهام: نافذة الدنجن ونافذة "Entering New Map"
        "sweep_btn" to intArrayOf(0, 560, 388, 660),
        "free_btn" to intArrayOf(0, 560, 388, 660),
        "enter_btn" to intArrayOf(0, 440, 388, 560),
        "entering_hdr" to intArrayOf(0, 280, 388, 380),
    ) + Catalog.maps.associate { it.key to intArrayOf(0, 270, 388, 800) } +
        Catalog.dungeons.associate { it.key to intArrayOf(0, 190, 388, 800) }

    private val coreTemplates = setOf(
        "watch_video", "coin", "okay", "seller_idle", "monitor_idle", "trophy", "ach_header", "ach_close",
        "continue_btn", "map_hdr", "map_close", "new_lbl", "time_warp_btn", "return_to", "confirm_btn",
    )

    init {
        for (name in roi.keys) {
            try {
                val bytes = ctx.assets.open("templates/$name.png").use { it.readBytes() }
                val m = Imgcodecs.imdecode(MatOfByte(*bytes), Imgcodecs.IMREAD_COLOR)
                require(!m.empty()) { "template $name لم يتحمّل" }
                tpl[name] = m
            } catch (e: Throwable) {
                // الصور الأساسية للشغل القديم لازم تتحمّل. أي صورة تانية (قائمة المهام) لو فشلت منكمّلش بيها بس.
                if (name in coreTemplates) throw e
                BotService.log("تحذير: صورة $name ما اتحمّلتش")
            }
        }
    }

    /** يحوّل الـ Bitmap لـ Mat بصيغة BGR ومقاس 388x848. */
    fun prepare(bmp: Bitmap): Mat {
        val rgba = Mat()
        Utils.bitmapToMat(bmp, rgba)
        val small = Mat()
        Imgproc.resize(rgba, small, Size(W.toDouble(), H.toDouble()), 0.0, 0.0, Imgproc.INTER_AREA)
        val bgr = Mat()
        Imgproc.cvtColor(small, bgr, Imgproc.COLOR_RGBA2BGR)
        rgba.release()
        small.release()
        return bgr
    }

    fun find(frame: Mat, name: String, threshold: Double): Hit? {
        val t = tpl[name] ?: return null
        val r = roi[name] ?: return null
        val x0 = r[0].coerceIn(0, W)
        val y0 = r[1].coerceIn(0, H)
        val x1 = r[2].coerceIn(0, W)
        val y1 = r[3].coerceIn(0, H)
        if (x1 - x0 < t.cols() || y1 - y0 < t.rows()) return null
        val sub = frame.submat(Rect(x0, y0, x1 - x0, y1 - y0))
        val res = Mat()
        Imgproc.matchTemplate(sub, t, res, Imgproc.TM_CCOEFF_NORMED)
        val mm = Core.minMaxLoc(res)
        res.release()
        sub.release()
        if (mm.maxVal < threshold) return null
        return Hit(
            x0 + mm.maxLoc.x.toInt() + t.cols() / 2,
            y0 + mm.maxLoc.y.toInt() + t.rows() / 2,
            mm.maxVal
        )
    }

    /**
     * أي نافذة عرض (تاجر أو مونيتور): زرار أزرق على اليمين (شراء أو Watch Video) وجنبه على الشمال
     * زرار أحمر (No Thanks). بنكشفها باللون والشكل مش بالنص أو نوع الحاجة المعروضة،
     * وبنقبل أحجام متفاوتة شوية.
     */
    fun findOffer(frame: Mat): Offer? {
        val oy = 420
        val sub = frame.submat(Rect(0, oy, W, 120))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val r1 = Mat(); val r2 = Mat(); val red = Mat(); val blue = Mat()
        Core.inRange(hsv, Scalar(0.0, 140.0, 110.0), Scalar(10.0, 255.0, 255.0), r1)
        Core.inRange(hsv, Scalar(170.0, 140.0, 110.0), Scalar(180.0, 255.0, 255.0), r2)
        Core.bitwise_or(r1, r2, red)
        Core.inRange(hsv, Scalar(90.0, 150.0, 120.0), Scalar(130.0, 255.0, 255.0), blue)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(25.0, 5.0))
        Imgproc.morphologyEx(blue, blue, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(blue, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        var result: Offer? = null
        for (c in contours) {
            val b = Imgproc.boundingRect(c)
            c.release()
            if (result != null) continue
            if (b.width !in 90..200 || b.height !in 30..72) continue
            val lx = b.x - b.width - 4
            if (lx < 0) continue
            val reg = red.submat(Rect(lx, b.y, b.width, b.height))
            val frac = Core.countNonZero(reg).toDouble() / (b.width * b.height)
            reg.release()
            if (frac > 0.30) {
                result = Offer(
                    Hit(lx + b.width / 2, oy + b.y + b.height / 2, 1.0),
                    Hit(b.x + b.width / 2, oy + b.y + b.height / 2, 1.0)
                )
            }
        }
        sub.release(); hsv.release(); r1.release(); r2.release(); red.release(); blue.release(); kernel.release()
        return result
    }

    /** زرار أخضر عريض في نص الشاشة (OKAY في نافذة "You received" بأي صيغة). */
    fun findBigGreenButton(frame: Mat): Hit? {
        val ox = 60
        val oy = 440
        val sub = frame.submat(Rect(ox, oy, 270, 80))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val mask = Mat()
        Core.inRange(hsv, Scalar(35.0, 120.0, 120.0), Scalar(85.0, 255.0, 255.0), mask)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(7.0, 7.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        var out: Hit? = null
        for (c in contours) {
            val b = Imgproc.boundingRect(c)
            c.release()
            if (out == null && b.width >= 190 && b.height in 34..58) {
                out = Hit(ox + b.x + b.width / 2, oy + b.y + b.height / 2, 1.0)
            }
        }
        sub.release(); hsv.release(); mask.release(); kernel.release()
        return out
    }

    /** نافذة "Entering New Map": زرار Enter أحمر على الشمال وNope أخضر على اليمين. بيرجّع مركز Enter. */
    fun findEnterDialog(frame: Mat): Hit? {
        val ox = 20
        val oy = 430
        val sub = frame.submat(Rect(ox, oy, 350, 150))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val r1 = Mat(); val r2 = Mat(); val red = Mat(); val green = Mat()
        Core.inRange(hsv, Scalar(0.0, 140.0, 190.0), Scalar(4.0, 255.0, 255.0), r1)
        Core.inRange(hsv, Scalar(172.0, 140.0, 190.0), Scalar(180.0, 255.0, 255.0), r2)
        Core.bitwise_or(r1, r2, red)
        Core.inRange(hsv, Scalar(35.0, 120.0, 170.0), Scalar(85.0, 255.0, 255.0), green)
        val reds = solidRects(red)
        val greens = solidRects(green)
        var out: Hit? = null
        for (r in reds) {
            for (g in greens) {
                val gap = g.x - (r.x + r.width)
                val dy = Math.abs((g.y + g.height / 2) - (r.y + r.height / 2))
                if (out == null && gap in 0..80 && dy < 12) {
                    out = Hit(ox + r.x + r.width / 2, oy + r.y + r.height / 2, 1.0)
                }
            }
        }
        sub.release(); hsv.release(); r1.release(); r2.release(); red.release(); green.release()
        return out
    }

    /** مستطيلات مصمتة بحجم زرار (عرض 90..170، ارتفاع 30..64). */
    private fun solidRects(mask: Mat): List<Rect> {
        val m = mask.clone()
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0))
        Imgproc.morphologyEx(m, m, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(m, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val out = ArrayList<Rect>()
        for (c in contours) {
            val b = Imgproc.boundingRect(c)
            val fill = Imgproc.contourArea(c) / (b.width * b.height).toDouble()
            c.release()
            if (b.width in 90..170 && b.height in 30..64 && fill > 0.7) out.add(b)
        }
        m.release(); kernel.release()
        return out
    }

    /** زرار أخضر عريض مصمت (Continue في نهاية الدنجن) في نص الشاشة. أضيق من 150 بكسل (زي فقاعة العملة) بيتجاهله. */
    fun findWideGreen(frame: Mat): Hit? {
        val ox = 30
        val oy = 300
        val sub = frame.submat(Rect(ox, oy, 330, 490))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val mask = Mat()
        Core.inRange(hsv, Scalar(35.0, 120.0, 120.0), Scalar(85.0, 255.0, 255.0), mask)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(7.0, 7.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        var out: Hit? = null
        for (c in contours) {
            val b = Imgproc.boundingRect(c)
            val fill = Imgproc.contourArea(c) / (b.width * b.height).toDouble()
            c.release()
            if (out == null && b.width in 150..330 && b.height in 34..64 && fill > 0.8) {
                out = Hit(ox + b.x + b.width / 2, oy + b.y + b.height / 2, 1.0)
            }
        }
        sub.release(); hsv.release(); mask.release(); kernel.release()
        return out
    }

    /** التبويب المفعّل في شاشة Select Map: 0 = Main، 1 = Dungeons، 2 = Event، -1 = مش معروف. */
    fun tab(frame: Mat): Int {
        val xs = intArrayOf(64, 194, 321)
        for (i in xs.indices) {
            val sub = frame.submat(Rect(xs[i] - 30, 119, 61, 9))
            val hsv = Mat()
            Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
            val mask = Mat()
            Core.inRange(hsv, Scalar(90.0, 150.0, 150.0), Scalar(115.0, 255.0, 255.0), mask)
            val frac = Core.countNonZero(mask).toDouble() / (61 * 9)
            sub.release(); hsv.release(); mask.release()
            if (frac > 0.4) return i
        }
        return -1
    }

    /** هل زرار الصعوبة ده مفتوح (مش مقفول)؟ المقفول بني غامق، المفتوح فاتح. */
    fun buttonEnabled(frame: Mat, x: Int, y: Int): Boolean {
        val rx = (x - 22).coerceIn(0, W - 45)
        val ry = (y - 5).coerceIn(0, H - 11)
        val sub = frame.submat(Rect(rx, ry, 45, 11))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val v = Core.mean(hsv).`val`[2]
        sub.release(); hsv.release()
        return v >= 160.0
    }

    /** نسخة مقصوصة من الفريم (بمقاس 388x848) لقراءتها بالـ OCR. */
    fun crop(frame: Mat, x: Int, y: Int, w: Int, h: Int): Mat =
        frame.submat(Rect(x.coerceIn(0, W - 1), y.coerceIn(0, H - 1), w.coerceAtMost(W - x), h.coerceAtMost(H - y))).clone()

    /** كل التطابقات فوق الحد (مثلاً علامات NEW! في قائمة الخرائط)، من فوق لتحت. */
    fun findAll(frame: Mat, name: String, threshold: Double, max: Int = 6): List<Hit> {
        val t = tpl[name] ?: return emptyList()
        val r = roi[name] ?: return emptyList()
        val x0 = r[0].coerceIn(0, W)
        val y0 = r[1].coerceIn(0, H)
        val x1 = r[2].coerceIn(0, W)
        val y1 = r[3].coerceIn(0, H)
        if (x1 - x0 < t.cols() || y1 - y0 < t.rows()) return emptyList()
        val sub = frame.submat(Rect(x0, y0, x1 - x0, y1 - y0))
        val res = Mat()
        Imgproc.matchTemplate(sub, t, res, Imgproc.TM_CCOEFF_NORMED)
        val out = ArrayList<Hit>()
        for (i in 0 until max) {
            val mm = Core.minMaxLoc(res)
            if (mm.maxVal < threshold) break
            val px = mm.maxLoc.x.toInt()
            val py = mm.maxLoc.y.toInt()
            out.add(Hit(x0 + px + t.cols() / 2, y0 + py + t.rows() / 2, mm.maxVal))
            // امسح الجيران عشان ما نعدّش نفس العلامة مرتين
            Imgproc.rectangle(
                res, org.opencv.core.Point((px - 20).toDouble(), (py - 10).toDouble()),
                org.opencv.core.Point((px + 20).toDouble(), (py + 10).toDouble()),
                Scalar(-1.0), -1
            )
        }
        res.release()
        sub.release()
        return out.sortedBy { it.y }
    }

    /** دايرة الـ "!" الزرقاء على أيقونة الكأس. تُستخدم فقط لما الكأس نفسها ظاهرة (يعني الشاشة هي اللعبة). */
    fun hasAchievementBadge(frame: Mat): Boolean {
        // دايرة صغيرة زرقاء غامقة تحت يمين الكاس. المنطقة ضيقة عشان خلفية الخريطة الزرقاء
        // (تحت الأزرار) ما تتحسبش، وبنرفض لو الأزرق مالي المنطقة كلها (سماء/خلفية).
        val sub = frame.submat(Rect(334, 84, 26, 19))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val mask = Mat()
        Core.inRange(hsv, Scalar(95.0, 150.0, 150.0), Scalar(115.0, 255.0, 255.0), mask)
        val n = Core.countNonZero(mask)
        sub.release(); hsv.release(); mask.release()
        return n in 25..200
    }

    /** أزرار الاستلام الخضرا داخل نافذة الإنجازات. بترجّع المراكز من فوق لتحت. */
    fun claimButtons(frame: Mat): List<Hit> {
        val ox = 220
        val oy = 100
        val sub = frame.submat(Rect(ox, oy, 150, 680))
        val hsv = Mat()
        Imgproc.cvtColor(sub, hsv, Imgproc.COLOR_BGR2HSV)
        val mask = Mat()
        Core.inRange(hsv, Scalar(35.0, 120.0, 150.0), Scalar(85.0, 255.0, 255.0), mask)
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel)
        val contours = ArrayList<MatOfPoint>()
        Imgproc.findContours(mask, contours, Mat(), Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        val out = ArrayList<Hit>()
        for (c in contours) {
            val b = Imgproc.boundingRect(c)
            if (b.width in 60..110 && b.height in 22..45) {
                out.add(Hit(ox + b.x + b.width / 2, oy + b.y + b.height / 2, 1.0))
            }
            c.release()
        }
        sub.release(); hsv.release(); mask.release(); kernel.release()
        return out.sortedBy { it.y }
    }

    /** بصمة صغيرة لمنطقة القائمة، لمعرفة هل السحب حرّك القائمة ولا وصلنا للآخر. */
    fun panelSignature(frame: Mat): Mat {
        val sub = frame.submat(Rect(100, 110, 115, 640))   // عمود الأسماء بس (الأزرار فيها حركة)
        val gray = Mat()
        Imgproc.cvtColor(sub, gray, Imgproc.COLOR_BGR2GRAY)
        val small = Mat()
        Imgproc.resize(gray, small, Size(30.0, 128.0), 0.0, 0.0, Imgproc.INTER_AREA)
        sub.release(); gray.release()
        return small
    }

    fun sameSignature(a: Mat, b: Mat): Boolean {
        val d = Mat()
        Core.absdiff(a, b, d)
        val mean = Core.mean(d).`val`[0]
        d.release()
        return mean < 4.0
    }
}

package com.example.sgbot

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.concurrent.TimeUnit

/**
 * قراءة الليفل من نافذة الدنجن بـ ML Kit (النموذج جوه التطبيق، من غير إنترنت).
 * الأرقام في اللعبة سماوي بحدود غامقة وبتتلخبط (3 مع 8) لو اتقرت زي ما هي،
 * فبنعزل لون الرقم الأول ونرسمه أسود على أبيض، وده بيدّي قراءة نضيفة.
 * لازم تتنادى من thread غير الـ main (الخدمة بتناديها من thread الشغل).
 */
class Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    /** الليفل الظاهر في النجمة الصفرا (فوق أزرار Sweep / Free Challenge)، أو null لو ما اتقراش. */
    fun readLevel(det: Detector, frame: Mat): Int? {
        val crop = det.crop(frame, 150, 492, 76, 54)
        val hsv = Mat()
        val mask = Mat()
        val big = Mat()
        val inv = Mat()
        val padded = Mat()
        val rgba = Mat()
        try {
            Imgproc.cvtColor(crop, hsv, Imgproc.COLOR_BGR2HSV)
            Core.inRange(hsv, Scalar(80.0, 60.0, 140.0), Scalar(115.0, 255.0, 255.0), mask)
            if (Core.countNonZero(mask) < 80) return null          // مفيش رقم باللون ده
            Imgproc.resize(mask, big, Size(), 4.0, 4.0, Imgproc.INTER_CUBIC)
            Imgproc.threshold(big, big, 127.0, 255.0, Imgproc.THRESH_BINARY)
            val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(5.0, 5.0))
            Imgproc.morphologyEx(big, big, Imgproc.MORPH_CLOSE, k)
            k.release()
            Core.bitwise_not(big, inv)                              // رقم أسود على خلفية بيضا
            Core.copyMakeBorder(inv, padded, 20, 20, 20, 20, Core.BORDER_CONSTANT, Scalar(255.0))
            Imgproc.cvtColor(padded, rgba, Imgproc.COLOR_GRAY2RGBA)
            val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(rgba, bmp)
            val text = try {
                Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 4, TimeUnit.SECONDS).text
            } catch (_: Throwable) {
                ""
            } finally {
                bmp.recycle()
            }
            val n = Regex("\\d{1,3}").find(text)?.value?.toIntOrNull()
            return if (n != null && n in 1..999) n else null
        } finally {
            crop.release(); hsv.release(); mask.release(); big.release()
            inv.release(); padded.release(); rgba.release()
        }
    }
}

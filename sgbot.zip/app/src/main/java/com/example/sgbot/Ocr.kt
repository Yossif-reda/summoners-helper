package com.example.sgbot

import android.graphics.Bitmap
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import java.util.concurrent.TimeUnit

/**
 * قراءة الأرقام من نافذة الدنجن (الليفل وعدد المفاتيح) بـ ML Kit (النموذج جوه التطبيق، من غير إنترنت).
 * لازم تتنادى من thread غير الـ main (الخدمة بتناديها من thread الشغل).
 */
class Ocr {
    private val rec by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    private fun recognize(crop: Mat, scale: Double): String {
        var big: Mat? = null
        var rgba: Mat? = null
        try {
            big = Mat()
            Imgproc.resize(crop, big, Size(), scale, scale, Imgproc.INTER_CUBIC)
            rgba = Mat()
            Imgproc.cvtColor(big, rgba, Imgproc.COLOR_BGR2RGBA)
            val bmp = Bitmap.createBitmap(rgba.cols(), rgba.rows(), Bitmap.Config.ARGB_8888)
            Utils.matToBitmap(rgba, bmp)
            val res = Tasks.await(rec.process(InputImage.fromBitmap(bmp, 0)), 4, TimeUnit.SECONDS)
            bmp.recycle()
            return res.text
        } catch (_: Throwable) {
            return ""
        } finally {
            big?.release()
            rgba?.release()
        }
    }

    /** الليفل الظاهر في النجمة الصفرا (فوق أزرار Sweep / Free Challenge). */
    fun readLevel(det: Detector, frame: Mat): Int? {
        val crop = det.crop(frame, 150, 492, 76, 54)
        try {
            val text = recognize(crop, 3.0)
            // ممكن يقرا كلمة Level كمان، فناخد آخر رقم
            val n = Regex("\\d{1,3}").findAll(text).lastOrNull()?.value?.toIntOrNull()
            return if (n != null && n in 1..999) n else null
        } finally {
            crop.release()
        }
    }
}

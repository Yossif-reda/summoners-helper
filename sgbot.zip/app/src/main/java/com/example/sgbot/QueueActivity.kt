package com.example.sgbot

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

/** شاشة قائمة المهام: إضافة وترتيب وحذف، وتشغيل القائمة. */
class QueueActivity : Activity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var list: LinearLayout
    private lateinit var info: TextView
    private lateinit var queueSwitch: Switch
    private val prefs get() = getSharedPreferences(BotService.PREFS, Context.MODE_PRIVATE)

    private val tick = object : Runnable {
        override fun run() {
            render()
            ui.postDelayed(this, 1500)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(24), dp(16), dp(12))
        }
        root.addView(TextView(this).apply {
            text = "قائمة المهام"
            textSize = 22f
            setTypeface(null, Typeface.BOLD)
        })
        info = TextView(this).apply { textSize = 13f; setPadding(0, dp(6), 0, dp(6)) }
        root.addView(info)

        queueSwitch = Switch(this).apply {
            text = "تشغيل القائمة (البوت ينفّذها بالترتيب)"
            textSize = 16f
            isChecked = prefs.getBoolean("q_on", false)
            setPadding(0, dp(8), 0, dp(8))
            setOnCheckedChangeListener { _, on ->
                prefs.edit().putBoolean("q_on", on).apply()
                if (on && TaskQueue.current(this@QueueActivity) == null) {
                    Toast.makeText(this@QueueActivity, "مفيش مهام لسه (أو كلها خلصت). اضغط \"من الأول\"", Toast.LENGTH_LONG).show()
                }
            }
        }
        root.addView(queueSwitch)

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(btn("+ مهمة") { showAddDialog() })
        row1.addView(btn("+ جاهز") { showPresets() })
        root.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(btn("من الأول") {
            TaskQueue.resetProgress(this)
            render()
        })
        row2.addView(btn("مسح الكل") {
            AlertDialog.Builder(this)
                .setMessage("تمسح كل المهام؟")
                .setPositiveButton("مسح") { _, _ ->
                    TaskQueue.save(this, emptyList())
                    TaskQueue.setLaunched(this, false)
                    render()
                }
                .setNegativeButton("لأ", null)
                .show()
        })
        root.addView(row2)

        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) },
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)
    }

    private fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        setOnClickListener { onClick() }
        layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
    }

    override fun onResume() {
        super.onResume()
        queueSwitch.isChecked = prefs.getBoolean("q_on", false)
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    // ---------- عرض القائمة ----------
    private fun render() {
        val tasks = TaskQueue.load(this)
        val cur = tasks.firstOrNull { !it.done }
        val doneCount = tasks.count { it.done }
        info.text = "المهام: ${tasks.size}  |  خلصت: $doneCount" +
            (if (cur != null && prefs.getBoolean("q_on", false) && TaskQueue.launched(this)) "  |  شغّالة دلوقتي" else "") +
            "\nالدنجن: البوت يلعب Free Challenge (من غير مفاتيح) لحد ما الليفل الظاهر يوصل الرقم اللي تحدده."
        if (queueSwitch.isChecked != prefs.getBoolean("q_on", false)) {
            queueSwitch.isChecked = prefs.getBoolean("q_on", false)   // اتقفلت لما القائمة خلصت
        }

        list.removeAllViews()
        if (tasks.isEmpty()) {
            list.addView(TextView(this).apply {
                text = "\nمفيش مهام. اضغط \"+ مهمة\" أو \"+ جاهز\"."
                textSize = 15f
            })
            return
        }
        tasks.forEachIndexed { i, t ->
            val isCur = t.id == cur?.id
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(6), dp(6), dp(6), dp(6))
                if (isCur) setBackgroundColor(Color.argb(40, 46, 160, 67))
            }
            val mark = when {
                t.done -> "✓"
                isCur -> "▶"
                else -> "○"
            }
            val label = TextView(this).apply {
                text = "$mark ${i + 1}. ${t.title()}" +
                    (if (t.note.isNotEmpty()) "\n    ${t.note}" else "") +
                    (if (!t.done && t.type == TaskType.DUNGEON && t.knownLevel > 0) "\n    الليفل الحالي: ${t.knownLevel}" else "")
                textSize = 14f
                setTextColor(if (t.done) Color.GRAY else Color.BLACK)
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }
            row.addView(label)
            row.addView(small("▲") { move(i, -1) })
            row.addView(small("▼") { move(i, +1) })
            row.addView(small("✕") { remove(i) })
            list.addView(row)
        }
    }

    private fun small(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        minWidth = 0; minimumWidth = 0
        setPadding(dp(10), 0, dp(10), 0)
        setOnClickListener { onClick() }
    }

    private fun move(i: Int, d: Int) {
        TaskQueue.update(this) { l ->
            val j = i + d
            if (i in l.indices && j in l.indices) {
                val t = l.removeAt(i)
                l.add(j, t)
            }
        }
        render()
    }

    private fun remove(i: Int) {
        TaskQueue.update(this) { l -> if (i in l.indices) l.removeAt(i) }
        TaskQueue.setLaunched(this, false)
        render()
    }

    // ---------- إضافة مهمة ----------
    private fun showAddDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(20), dp(12), dp(20), 0)
        }
        val typeGroup = RadioGroup(this).apply { orientation = RadioGroup.HORIZONTAL }
        val rMap = RadioButton(this).apply { text = "ماب (Main)"; id = View.generateViewId() }
        val rDun = RadioButton(this).apply { text = "دنجن"; id = View.generateViewId() }
        typeGroup.addView(rMap); typeGroup.addView(rDun)
        rMap.isChecked = true
        box.addView(typeGroup)

        val nameSpin = Spinner(this)
        val diffSpin = Spinner(this).apply {
            adapter = ArrayAdapter(this@QueueActivity, android.R.layout.simple_spinner_dropdown_item, Catalog.diffNames)
        }
        val lvl = EditText(this).apply {
            hint = "يوقف لما الليفل الظاهر يوصل (مثلًا 40)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        box.addView(nameSpin)
        box.addView(diffSpin)
        box.addView(lvl)

        fun apply(isMap: Boolean) {
            val names = (if (isMap) Catalog.maps else Catalog.dungeons).map { it.label }
            nameSpin.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            diffSpin.visibility = if (isMap) View.VISIBLE else View.GONE
            lvl.visibility = if (isMap) View.GONE else View.VISIBLE
        }
        apply(true)
        typeGroup.setOnCheckedChangeListener { _, id -> apply(id == rMap.id) }

        AlertDialog.Builder(this)
            .setTitle("مهمة جديدة")
            .setView(box)
            .setPositiveButton("إضافة") { _, _ ->
                val isMap = rMap.isChecked
                val item = (if (isMap) Catalog.maps else Catalog.dungeons)[nameSpin.selectedItemPosition]
                val ok = if (isMap) {
                    TaskQueue.add(this, TaskType.MAP, item.key, diffSpin.selectedItemPosition, 0)
                } else {
                    val n = lvl.text.toString().toIntOrNull()
                    if (n == null || n < 1) {
                        Toast.makeText(this, "اكتب رقم الليفل", Toast.LENGTH_SHORT).show()
                        return@setPositiveButton
                    }
                    TaskQueue.add(this, TaskType.DUNGEON, item.key, 0, n)
                }
                if (!ok) Toast.makeText(this, "القائمة مليانة (${TaskQueue.MAX_TASKS} مهمة)", Toast.LENGTH_SHORT).show()
                render()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    // ---------- إعدادات جاهزة ----------
    private fun showPresets() {
        val items = arrayOf(
            "كل المابات Normal",
            "كل المابات Expert",
            "كل المابات Heroic",
            "ماب معيّن: Normal ثم Expert ثم Heroic",
            "كل الدنجنز لحد ليفل...",
        )
        AlertDialog.Builder(this)
            .setTitle("إضافة جاهزة")
            .setItems(items) { _, which ->
                when (which) {
                    0, 1, 2 -> {
                        Catalog.maps.forEach { TaskQueue.add(this, TaskType.MAP, it.key, which, 0) }
                        render()
                    }
                    3 -> pickMapForAllDiffs()
                    4 -> askDungeonLevel()
                }
            }
            .show()
    }

    private fun pickMapForAllDiffs() {
        val names = Catalog.maps.map { it.label }.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("اختار الماب")
            .setItems(names) { _, i ->
                for (d in 0..2) TaskQueue.add(this, TaskType.MAP, Catalog.maps[i].key, d, 0)
                render()
            }
            .show()
    }

    private fun askDungeonLevel() {
        val input = EditText(this).apply {
            hint = "الليفل المطلوب (مثلًا 40)"
            inputType = InputType.TYPE_CLASS_NUMBER
        }
        AlertDialog.Builder(this)
            .setTitle("كل الدنجنز لحد ليفل")
            .setView(input)
            .setPositiveButton("إضافة") { _, _ ->
                val n = input.text.toString().toIntOrNull()
                if (n == null || n < 1) {
                    Toast.makeText(this, "اكتب رقم الليفل", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // مش بنضيف The Master's Challenge: مفتاحه 1/1 وله نظام تاني
                Catalog.dungeons.filter { it.key != "dun_master" }
                    .forEach { TaskQueue.add(this, TaskType.DUNGEON, it.key, 0, n) }
                render()
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}

package com.example.sgbot

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

enum class TaskType { MAP, DUNGEON }

/** عنصر في الكتالوج: key هو اسم الـ template (الصورة) اللي بتتعرّف على اسم الماب أو الدنجن. */
data class CatalogItem(val key: String, val label: String)

object Catalog {
    // بترتيبها في اللعبة. لو نزلت ماب أو دنجن جديد: قص صورة اسمه وحطها في templates وضيفه هنا.
    val maps = listOf(
        CatalogItem("map_king", "The King"),
        CatalogItem("map_ragefist", "Ragefist Chieftain"),
        CatalogItem("map_joint", "The Joint Revenge"),
        CatalogItem("map_icequeen", "The Ice Queen's Storm"),
        CatalogItem("map_backyard", "Summoner's Backyard"),
        CatalogItem("map_meat", "Meat of the Matter"),
        CatalogItem("map_volcano", "Volcano Goddess's Eruption"),
        CatalogItem("map_kami", "Kami Pantheon's Reckoning"),
        CatalogItem("map_spectre", "Spectre Club"),
    )
    val dungeons = listOf(
        CatalogItem("dun_might", "Trial of Might"),
        CatalogItem("dun_ice", "Trial of Ice"),
        CatalogItem("dun_fire", "Trial of Fire"),
        CatalogItem("dun_lightning", "Trial of Lightning"),
        CatalogItem("dun_cosmic", "Trial of the Cosmic"),
        CatalogItem("dun_armor", "Trial of Armor"),
        CatalogItem("dun_weapons", "Trial of Weapons"),
        CatalogItem("dun_charms", "Trial of Charms"),
        CatalogItem("dun_pirate", "Pirate Cats vs Queen"),
        CatalogItem("dun_master", "The Master's Challenge"),
    )
    val diffNames = listOf("Normal", "Expert", "Heroic")
    /** مكان زرار كل صعوبة (x) في صف الماب، بمقاس 388x848. */
    val diffX = intArrayOf(80, 195, 311)

    fun label(key: String): String =
        (maps + dungeons).firstOrNull { it.key == key }?.label ?: key
}

class GameTask(
    val id: Long,
    val type: TaskType,
    val key: String,
    val diff: Int = 0,            // للمابات: 0 Normal / 1 Expert / 2 Heroic
    val target: Int = 0,          // للدنجنز: يوقف لما الليفل الظاهر يوصل الرقم ده
    var done: Boolean = false,
    var note: String = "",
    var plays: Int = 0,           // عدد مرات Free Challenge
    var knownLevel: Int = -1,     // آخر ليفل اتقرا (أو متوقّع)
) {
    fun title(): String = when (type) {
        TaskType.MAP -> "${Catalog.label(key)} - ${Catalog.diffNames[diff]}"
        TaskType.DUNGEON -> "${Catalog.label(key)} - لحد ليفل $target"
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("type", type.name).put("key", key).put("diff", diff)
        .put("target", target).put("done", done).put("note", note)
        .put("plays", plays).put("lvl", knownLevel)

    companion object {
        fun fromJson(o: JSONObject) = GameTask(
            id = o.getLong("id"),
            type = TaskType.valueOf(o.getString("type")),
            key = o.getString("key"),
            diff = o.optInt("diff", 0),
            target = o.optInt("target", 0),
            done = o.optBoolean("done", false),
            note = o.optString("note", ""),
            plays = o.optInt("plays", 0),
            knownLevel = o.optInt("lvl", -1),
        )
    }
}

/**
 * قائمة المهام (بتتحفظ في SharedPreferences، والخدمة والواجهة بيقروا منها).
 * كل العمليات synchronized عشان الواجهة والخدمة ما يكتبوش فوق بعض.
 */
object TaskQueue {
    private const val KEY = "queue_json"
    const val MAX_TASKS = 40

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(BotService.PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun load(ctx: Context): MutableList<GameTask> {
        val s = prefs(ctx).getString(KEY, null) ?: return mutableListOf()
        return try {
            val a = JSONArray(s)
            MutableList(a.length()) { GameTask.fromJson(a.getJSONObject(it)) }
        } catch (_: Throwable) {
            mutableListOf()
        }
    }

    @Synchronized
    fun save(ctx: Context, list: List<GameTask>) {
        val a = JSONArray()
        list.forEach { a.put(it.toJson()) }
        prefs(ctx).edit().putString(KEY, a.toString()).apply()
    }

    @Synchronized
    fun update(ctx: Context, block: (MutableList<GameTask>) -> Unit) {
        val l = load(ctx)
        block(l)
        save(ctx, l)
    }

    fun current(ctx: Context): GameTask? = load(ctx).firstOrNull { !it.done }

    fun nextId(list: List<GameTask>): Long = (list.maxOfOrNull { it.id } ?: 0L) + 1

    fun add(ctx: Context, type: TaskType, key: String, diff: Int, target: Int): Boolean {
        var ok = false
        update(ctx) { l ->
            if (l.size < MAX_TASKS) {
                l.add(GameTask(nextId(l), type, key, diff, target))
                ok = true
            }
        }
        return ok
    }

    /** يرجّع كل المهام لحالة "لسه ما اتعملتش". */
    fun resetProgress(ctx: Context) {
        update(ctx) { l -> l.forEach { it.done = false; it.note = ""; it.plays = 0; it.knownLevel = -1 } }
        setLaunched(ctx, false)
    }

    // ---- حالة: هل المهمة الحالية بدأت فعلًا (اللعبة ماشية جواها)؟ ----
    @Synchronized
    fun launched(ctx: Context): Boolean = prefs(ctx).getBoolean("q_launched", false)

    @Synchronized
    fun launchedAt(ctx: Context): Long = prefs(ctx).getLong("q_launched_at", 0L)

    @Synchronized
    fun setLaunched(ctx: Context, v: Boolean) {
        prefs(ctx).edit()
            .putBoolean("q_launched", v)
            .putLong("q_launched_at", if (v) System.currentTimeMillis() else 0L)
            .apply()
    }
}

"""يقصّ templates قائمة المهام من فريمات فيديو. الاستخدام: python3 make_queue_templates.py <مجلد الفريمات>"""
import sys
import cv2, os
F=sys.argv[1].rstrip('/')+'/f_%03d.png'   # مجلد الفريمات (ffmpeg -vf fps=1,scale=388:-1)
OUT=os.path.join(os.path.dirname(os.path.abspath(__file__)),'..','app/src/main/assets/templates'); os.makedirs(OUT,exist_ok=True)
# name: (frame, y_center, x0, x1)
MAPS={'map_king':(2,326),'map_ragefist':(2,485),'map_joint':(2,645),'map_icequeen':(11,363),
      'map_backyard':(11,523),'map_meat':(11,682),'map_volcano':(7,423),'map_kami':(7,583),'map_spectre':(9,647)}
DUN={'dun_might':(16,259),'dun_master':(16,378),'dun_ice':(21,268),'dun_fire':(21,388),'dun_lightning':(21,509),
     'dun_cosmic':(24,266),'dun_armor':(24,386),'dun_weapons':(24,507),'dun_charms':(24,627),'dun_pirate':(24,747)}
for n,(f,y) in MAPS.items():
    im=cv2.imread(F%f); cv2.imwrite(f'{OUT}/{n}.png',im[y-11:y+11,72:212])
for n,(f,y) in DUN.items():
    im=cv2.imread(F%f); cv2.imwrite(f'{OUT}/{n}.png',im[y-11:y+11,68:168])
# popup buttons / dialog
im=cv2.imread(F%31)
cv2.imwrite(f'{OUT}/sweep_btn.png',im[585:625,35:180])
cv2.imwrite(f'{OUT}/free_btn.png',im[585:625,195:340])
im=cv2.imread(F%45)
cv2.imwrite(f'{OUT}/enter_btn.png',im[486:526,45:175])
cv2.imwrite(f'{OUT}/entering_hdr.png',im[315:351,100:290])

"""يعيد تشغيل منطق البوت على frames مستخرجة من فيديو (ffmpeg -vf fps=1) ويطبع القرارات.
الاستخدام: python3 replay.py <مجلد frames بمقاس 388x848>"""
import cv2, numpy as np, glob, sys, os
T = os.path.join(os.path.dirname(__file__), '..', 'app/src/main/assets/templates')
roi = {'hdr_bonus':(60,180,330,260),'hdr_seller':(60,180,330,260),'watch_video':(0,420,388,540),'coin':(180,420,388,540),
 'okay':(40,430,350,530),'seller_idle':(230,600,388,780),'monitor_idle':(230,600,388,780),'trophy':(280,50,388,130),
 'ach_header':(60,40,330,120),'ach_close':(300,40,388,120),
 'continue_btn':(40,560,350,700),'map_hdr':(100,30,300,90),'map_close':(320,30,388,100),'new_lbl':(20,300,388,820),
 'time_warp_btn':(10,560,200,700),'return_to':(200,500,388,600),'confirm_btn':(100,770,290,848)}
tpl = {n: cv2.imread(f'{T}/{n}.png') for n in roi}
def find(f, n, thr):
    x0,y0,x1,y1 = roi[n]; t = tpl[n]
    res = cv2.matchTemplate(f[y0:y1,x0:x1], t, cv2.TM_CCOEFF_NORMED)
    _,mx,_,loc = cv2.minMaxLoc(res)
    return (x0+loc[0]+t.shape[1]//2, y0+loc[1]+t.shape[0]//2) if mx >= thr else None
def badge(f):
    hsv = cv2.cvtColor(f[88:112,330:358], cv2.COLOR_BGR2HSV)
    return cv2.countNonZero(cv2.inRange(hsv,(95,120,150),(115,255,255))) > 20
def claims(f):
    hsv = cv2.cvtColor(f[100:780,220:370], cv2.COLOR_BGR2HSV)
    m = cv2.inRange(hsv,(35,120,150),(85,255,255)); m = cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
    cs,_ = cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); out=[]
    for c in cs:
        x,y,w,h = cv2.boundingRect(c)
        if 60<=w<=110 and 22<=h<=45: out.append((220+x+w//2,100+y+h//2))
    return sorted(out,key=lambda p:p[1])
def new_labels(f):
    x0,y0,x1,y1 = roi['new_lbl']; t = tpl['new_lbl']
    res = cv2.matchTemplate(f[y0:y1,x0:x1], t, cv2.TM_CCOEFF_NORMED); out=[]
    for _ in range(6):
        _,mx,_,loc = cv2.minMaxLoc(res)
        if mx < .75: break
        out.append((x0+loc[0]+t.shape[1]//2, y0+loc[1]+t.shape[0]//2))
        cv2.rectangle(res,(max(0,loc[0]-20),max(0,loc[1]-10)),(loc[0]+20,loc[1]+10),-1,-1)
    return sorted(out,key=lambda p:p[1])
def find_offer(f):
    sub=f[420:540]; hsv=cv2.cvtColor(sub,cv2.COLOR_BGR2HSV)
    red=cv2.bitwise_or(cv2.inRange(hsv,(0,140,110),(10,255,255)),cv2.inRange(hsv,(170,140,110),(180,255,255)))
    o=cv2.morphologyEx(cv2.inRange(hsv,(35,110,110),(160,255,255)),cv2.MORPH_CLOSE,np.ones((15,25),np.uint8))
    for c in cv2.findContours(o,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[0]:
        x,y,w,h=cv2.boundingRect(c); lx=x-173
        if 120<=w<=200 and 36<=h<=64 and lx>=0 and lx+w<=388 and red[y:y+h,lx:lx+w].mean()/255>0.35:
            return (lx+w//2,420+y+h//2),(x+w//2,420+y+h//2)
def big_green(f):
    hsv=cv2.cvtColor(f[440:520,60:330],cv2.COLOR_BGR2HSV)
    m=cv2.morphologyEx(cv2.inRange(hsv,(35,120,120),(85,255,255)),cv2.MORPH_CLOSE,np.ones((7,7),np.uint8))
    for c in cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[0]:
        x,y,w,h=cv2.boundingRect(c)
        if w>=190 and 34<=h<=58: return (60+x+w//2,440+y+h//2)
def step(f, st):
    now = st['t']
    ok, ah = find(f,'okay',.8) or big_green(f), find(f,'ach_header',.8)
    of = find_offer(f)
    if of:
        if st['mode']=='AD': return None
        if find(f,'watch_video',.7): st['mode']='AD'; return f'TAP Watch Video {of[1]}'
        return f'TAP Buy (any offer) {of[1]}'
    if ok: st['mode']='IDLE'; st['cool']=now+12; return f'TAP OKAY {ok}'
    if ah:
        cl = claims(f)
        return f'TAP Claim {cl[0]}' if cl else 'ACH: scroll/close'
    rt = find(f,'return_to',.8)
    if rt: st['place']=now+90; return f'TAP Return to Wave {rt}'
    tw = find(f,'time_warp_btn',.8)
    if tw: return f'TAP Time Warp {tw}'
    if find(f,'map_hdr',.8):
        if now < st.get('win',0):
            news = new_labels(f)
            pick = ([n for n in news if n[0]<130] or [n for n in news if 130<=n[0]<=260] or news or [None])[0]
            if pick: st['place']=now+90; return f'TAP next map {(pick[0],pick[1]+26)}'
            return 'MAP: scroll'
        return None
    ct = find(f,'continue_btn',.8)
    if ct: st['win']=now+120; return f'TAP Continue {ct}'
    if now < st.get('place',0):
        cf = find(f,'confirm_btn',.8)
        if cf: st['place']=0; return f'TAP Confirm {cf}'
    if st['mode']=='AD': return None
    tr = find(f,'trophy',.75)
    if not tr or now < st['cool']: return None
    sp = find(f,'seller_idle',.72) or find(f,'monitor_idle',.72)
    if sp: return f'TAP sprite {sp}'
    if badge(f): return f'TAP trophy {tr}'
if __name__ == '__main__':
    fps = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
    st = {'mode':'IDLE','cool':0,'t':0}; last=None
    for i,p in enumerate(sorted(glob.glob(sys.argv[1]+'/*.png'))):
        st['t']=i/fps; a = step(cv2.imread(p), st)
        if a and a != last: print(f't={i/fps:.1f}s  {a}')
        last = a if a else last if a is None and last and last.startswith('TAP') and False else a

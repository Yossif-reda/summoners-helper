import cv2,numpy as np,glob,sys
S=sys.argv[1]; T='/home/claude/SummonersBot/templates'
names=['hdr_seller','hdr_bonus','watch_video','coin','okay','seller_idle','monitor_idle','trophy','ach_header','ach_close']
tpl={n:cv2.imread(f'{T}/{n}.png') for n in names}
# search ROI per template (x0,y0,x1,y1) in 388x848 space
roi={'hdr_seller':(60,180,330,260),'hdr_bonus':(60,180,330,260),'watch_video':(0,420,388,540),'coin':(180,420,388,540),'okay':(40,430,350,530),
     'seller_idle':(230,600,388,780),'monitor_idle':(230,600,388,780),'trophy':(280,50,388,130),
     'ach_header':(60,40,330,120),'ach_close':(300,40,388,120)}
def score(im,n):
    x0,y0,x1,y1=roi[n]; r=im[y0:y1,x0:x1]; t=tpl[n]
    if r.shape[0]<t.shape[0] or r.shape[1]<t.shape[1]: return 0
    res=cv2.matchTemplate(r,t,cv2.TM_CCOEFF_NORMED); return float(res.max())
def badge(im):
    r=im[88:112,330:358]; hsv=cv2.cvtColor(r,cv2.COLOR_BGR2HSV)
    m=cv2.inRange(hsv,(95,120,150),(115,255,255)); return int(m.sum()/255)
for vid in ('fa','fb'):
    files=sorted(glob.glob(f'{S}/{vid}/*.png'))
    rows=[]
    for f in files:
        im=cv2.imread(f); rows.append([score(im,n) for n in names]+[badge(im)])
    a=np.array(rows)
    print(vid,'frames',len(a))
    for k,n in enumerate(names+['badge']):
        col=a[:,k]
        thr=0.7 if n!='badge' else 20
        on=np.where(col>thr)[0]
        # runs
        runs=[];s=None
        for i in range(len(col)):
            if col[i]>thr and s is None: s=i
            if col[i]<=thr and s is not None: runs.append((s+1,i)); s=None
        if s is not None: runs.append((s+1,len(col)))
        print(f' {n:13s} max={col.max():.2f} runs={runs[:12]}')
np.save(S+'/scores.npy',a)

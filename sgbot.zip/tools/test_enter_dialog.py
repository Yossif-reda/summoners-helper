import cv2,numpy as np,glob
def rects(m,w,h):
    m=cv2.morphologyEx(m,cv2.MORPH_CLOSE,np.ones((5,5),np.uint8))
    cs,_=cv2.findContours(m,cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE); out=[]
    for c in cs:
        x,y,ww,hh=cv2.boundingRect(c)
        if w[0]<=ww<=w[1] and h[0]<=hh<=h[1] and cv2.contourArea(c)/(ww*hh)>0.7: out.append((x,y,ww,hh))
    return out
def enter(f):
    ox,oy=20,430; sub=f[oy:oy+150,ox:ox+350]; hsv=cv2.cvtColor(sub,cv2.COLOR_BGR2HSV)
    red=cv2.inRange(hsv,(0,140,190),(4,255,255))|cv2.inRange(hsv,(172,140,190),(180,255,255))
    green=cv2.inRange(hsv,(35,120,170),(85,255,255))
    R=rects(red,(90,170),(30,64)); G=rects(green,(90,170),(30,64))
    for r in R:
        for g in G:
            gap=g[0]-(r[0]+r[2])
            if 0<=gap<=80 and abs((g[1]+g[3]/2)-(r[1]+r[3]/2))<12: return (ox+r[0]+r[2]//2,oy+r[1]+r[3]//2)
    return None
if __name__=='__main__':
    for p in sorted(glob.glob('/home/claude/vid_frames/f_*.png')):
        r=enter(cv2.imread(p))
        if r: print(p[-7:],r)

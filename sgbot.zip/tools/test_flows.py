"""يختبر templates الفوز/الخسارة على مجلدات frames (388x848). الاستخدام: python3 test_flows.py dir1 dir2 ..."""
import cv2, numpy as np, glob, sys, os
T = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app/src/main/assets/templates')
roi = {'continue_btn':(40,560,350,700),'map_hdr':(100,30,300,90),'map_close':(320,30,388,100),'new_lbl':(20,300,388,820),
       'time_warp_btn':(10,560,200,700),'return_to':(200,500,388,600),'confirm_btn':(100,770,290,848)}
tpl = {n: cv2.imread(f'{T}/{n}.png') for n in roi}
def score(f, n):
    x0,y0,x1,y1 = roi[n]; r = f[y0:y1,x0:x1]
    return float(cv2.matchTemplate(r, tpl[n], cv2.TM_CCOEFF_NORMED).max())
for d in sys.argv[1:]:
    fs = sorted(glob.glob(d+'/*.png')); a = np.array([[score(cv2.imread(f), n) for n in roi] for f in fs])
    print(d, len(fs))
    for k,n in enumerate(roi):
        col=a[:,k]; on=np.where(col>0.8)[0]+1
        runs=[]; 
        for i in on:
            if runs and i-runs[-1][1]<=1: runs[-1][1]=i
            else: runs.append([i,i])
        print(f'  {n:14s} max={col.max():.2f} runs={runs[:8]}')

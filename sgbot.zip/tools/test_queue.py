"""يختبر templates قائمة المهام (أسماء المابات/الدنجنز، نافذة الدنجن، Enter) وكشف التبويب وزرار الصعوبة
على frames بمقاس 388x848. الاستخدام: python3 test_queue.py <مجلد frames>"""
import cv2, numpy as np, glob, os, sys
T = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'app/src/main/assets/templates')
maps = ['map_king','map_ragefist','map_joint','map_icequeen','map_backyard','map_meat','map_volcano','map_kami','map_spectre']
duns = ['dun_might','dun_ice','dun_fire','dun_lightning','dun_cosmic','dun_armor','dun_weapons','dun_charms','dun_pirate','dun_master']
roi = {'sweep_btn':(0,560,388,660),'free_btn':(0,560,388,660),'enter_btn':(0,440,388,560),'entering_hdr':(0,280,388,380)}
roi.update({m:(0,270,388,800) for m in maps}); roi.update({d:(0,190,388,800) for d in duns})
tpl = {n: cv2.imread(f'{T}/{n}.png') for n in roi}
def find(f, n, thr=0.85):
    x0,y0,x1,y1 = roi[n]; t = tpl[n]
    res = cv2.matchTemplate(f[y0:y1,x0:x1], t, cv2.TM_CCOEFF_NORMED); _,mx,_,loc = cv2.minMaxLoc(res)
    return (x0+loc[0]+t.shape[1]//2, y0+loc[1]+t.shape[0]//2) if mx >= thr else None
def tab(f):
    for i,x in enumerate((64,194,321)):
        hsv = cv2.cvtColor(f[119:128,x-30:x+31], cv2.COLOR_BGR2HSV)
        if cv2.countNonZero(cv2.inRange(hsv,(90,150,150),(115,255,255)))/(61*9) > 0.4: return i
    return -1
def enabled(f, x, y):
    hsv = cv2.cvtColor(f[y-5:y+6, x-22:x+23], cv2.COLOR_BGR2HSV)
    return hsv[:,:,2].mean() >= 160
for d in sys.argv[1:]:
    for p in sorted(glob.glob(d+'/*.png')):
        f = cv2.imread(p); out = []
        t = tab(f)
        if t >= 0: out.append(f'tab={["Main","Dungeons","Event"][t]}')
        for n in maps:
            h = find(f, n, .87)
            if h: out.append(f'{n}@y{h[1]}' + ''.join('NEH'[i] if enabled(f, x, h[1]+91) else 'x'
                             for i,x in enumerate((80,195,311))))
        for n in duns:
            h = find(f, n, .87)
            if h: out.append(f'{n}@y{h[1]}')
        if find(f,'free_btn') and find(f,'sweep_btn'): out.append('DUNGEON_POPUP')
        if find(f,'entering_hdr'): out.append('ENTER_DIALOG')
        print(os.path.basename(p), ' '.join(out))
